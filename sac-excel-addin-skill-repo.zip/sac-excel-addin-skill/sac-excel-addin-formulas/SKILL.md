---
name: sac-excel-addin-formulas
description: Build, review and debug formulas for the SAP Analytics Cloud (SAC) add-in for Microsoft Excel — all 16 SAP.* functions (GETDATA, SETDATA, GETDATACOMMENT, GETDIMENSIONFILTER, OVERWRITEDIMENSIONFILTER, ASYMMETRICFILTER, BLOCK, TIMEOFFSET, GETTABLENAME, GETTABLESTATUS, GETDIMENSIONS, GETVARIABLES, MEMBERPROPERTY and the planning-trigger functions). Use for asymmetric reports, KPI sheets, variance and rolling reports, dropdown-driven filters, planning input forms and write-back, driver-based plans, rolling forecasts, data action / multi action run panels, member property lookups, repointable templates, generating workbooks with code and binding their SAP formulas, reading dimension IDs from a connected workbook, and fixing #NAME?, blank or wrong SAP formula results. Trigger on "SAC add-in", "SAP.GETDATA", "SAC Excel formula", "write-back from Excel", "SAC planning in Excel", or any SAP.* formula, even if no function is named.
---

# SAP Analytics Cloud add-in for Excel: formulas, reports and planning

The SAC add-in adds **16 native Excel functions** (category *SAP Analytics Cloud*). They read
from SAC models, live SAP Datasphere models and S/4HANA CDS views, and write back to SAC planning
models. They are ordinary Excel functions, so they mix with `IF`, `XLOOKUP`, `SEQUENCE`, data
validation, charts and conditional formatting. That is what lets reports and input forms take
any layout instead of the fixed table grid.

This skill gives you correct signatures, proven patterns, a planning workflow, a way to bind
generated workbooks, and a troubleshooting decoder. It doesn't assume any industry or model:
swap in your own dimension and member IDs.

## Pick the mode first

| The task is… | Do this |
|---|---|
| One formula or a small grid | *Build a formula* below. Signatures: `references/function-reference.md` |
| A report, dashboard or reusable template | **Run the intake first** (`references/report-architecture.md` §0), then architecture + patterns |
| Write-back / planning / triggers | `references/planning.md` |
| Code writes or edits the .xlsx; IDs needed from a connected file | `references/workbook-engineering.md` + `scripts/sac_xlsx_tools.py` |
| "It shows #NAME? / blank / wrong number" | `references/troubleshooting.md` |
| Need inspiration or a starting layout | `references/patterns.md`; the repo's `docs/use-cases.html` |

For a full report, **ask the business questions before writing formulas**: source model,
pinned dimensions, time logic (MTD/YTD, rolling, comparative), versions and currency that
really exist, write-back needs, and one known number to reconcile against. Wrong assumptions
here give numbers that look plausible but are wrong.

## Build a formula

1. **Pick the function** from the selector below.
2. **Get the data source name:**
   - a table name (`"Table1"`, or what `=SAP.GETTABLENAME(<cell in table>)` returns), or
   - a **data source for formulas** alias (`"DS_1"`), added with *Designer → Add Data Source for
     Formulas*. That needs no table.

   Keep the name as a plain value in a Control cell and reference that cell.
3. **Use IDs, not descriptions**, for dimensions and members (`"public.Actual"`, `"202501"`,
   `"1000"`). Copy the exact dimension IDs from `=SAP.GETDIMENSIONS(src,0,0,1)`.
4. **Pin what matters.** A dimension you leave out takes the member in the data source's filter,
   so the number can change when someone edits the filter. Name every dimension the number
   depends on. Use one member per pair; never use `""` or "All members" to mean everything.
5. **Anchor references** so one formula fills a grid (`$A5` row IDs, `C$3` column IDs). For
   templates, put the **dimension IDs in Control cells** as well: both arguments accept cell
   references.
6. **Use the builder for anything repetitive.** It handles quoting, option codes and the list
   separator:
   ```
   python scripts/build_formula.py GETDATA --table '$B$1' --pairs Account='$A5' Date='C$3' Version=public.Actual
   python scripts/build_formula.py TIMEOFFSET --table DS_1 --ref 202506 --offsets=-11..0 --orientation 1
   python scripts/build_formula.py grid --table 'Ctl!$B$3' --rows A5:A20 --cols C3:N3 --row-dim Account --col-dim Date --fixed Version=public.Actual
   python scripts/build_formula.py --help
   ```
   In ID positions, a reference must be unambiguous (`$A5`, `C$3`, `Sheet!B2`, `A1:A9`, `A9#`,
   or `ref:A5`). Otherwise a bare `CC100` or `P100` is quoted as a member ID.
7. **Test one value** with an unwrapped cell before filling a whole grid.

## Function selector

| Need | Function | Signature (optional args in [ ]) |
|---|---|---|
| Read a value | `SAP.GETDATA` | `(Table, Dim1, Mem1, [Dim2, Mem2…])` |
| Write a value (planning) | `SAP.SETDATA` | `(Table, Value, Dim1, Mem1, …)` |
| Read the last data point comment (± value) | `SAP.GETDATACOMMENT` | `(Table, Display 0–4, Dim1, Mem1, …)` |
| Show a filter + on-sheet filter button | `SAP.GETDIMENSIONFILTER` | `(Table, Dim, [Member_display 0–6], [Selection_display 0–4], [Orientation], [Separator])` |
| Set a filter from cells/dropdowns | `SAP.OVERWRITEDIMENSIONFILTER` | `(Tables, Dim, Members, [Selection_type 0–5], [Member_display 0–4], [Separator])` |
| Asymmetric table filter | `SAP.ASYMMETRICFILTER` | `(Tables, Block1, [Block2…])` |
| Build a block for the above | `SAP.BLOCK` | `(Dim1, Mem(s)1, … up to 5 pairs)` (no Table) |
| Relative periods (rolling) | `SAP.TIMEOFFSET` | `(Table, Reference_date, "Offsets", [Display 0–3], [Orientation], [Dimension])` |
| Table name of a cell | `SAP.GETTABLENAME` | `(Cell)` |
| Refresh status banner | `SAP.GETTABLESTATUS` | `("T1, T2", [Display 0–4])` |
| List dimension IDs | `SAP.GETDIMENSIONS` | `(Table, [Display 0–4], [Orientation], [Sort_order 0–2])` |
| Variable / prompt values | `SAP.GETVARIABLES` | `(Table, Variable, [Var_display], [Value_display], [Layout], [Orientation])` |
| Member attributes | `SAP.MEMBERPROPERTY` | `(Table, Dim, Members, "Prop1, Prop2", [Orientation])` |
| Trigger name in a cell | `SAP.GETPLANNINGTRIGGERNAME` | `(Cell)` |
| Trigger parameters | `SAP.GETPLANNINGTRIGGERPARAMETERS` | `(Trigger, [Display], [Orientation])` |
| Trigger parameter value + edit icon | `SAP.GETPLANNINGTRIGGERPARAMETERVALUE` | `(Trigger, Parameter, [Display 0–3], [Orientation])` |

Codes: Display 0 ID · 1 description · 2 ID+description · 3 description+ID · 4 full ID.
Orientation 0 vertical · 1 horizontal. **The defaults differ**: TIMEOFFSET and GETVARIABLES default
to horizontal, the others to vertical, so always pass Orientation. Selection type: 0 self +
descendants · 1 descendants · 2 self + children · 3 children · 4 self · 5 leaves.

**Not add-in functions** (they return `#NAME?`): `SAP.GETMEMBERS`, `SAP.GETMESSAGE`,
Analysis for Office `SAPGet…`/`SAPSet…`, and BPC `EPM…`. Equivalents are in the function reference.

## Rules that decide whether it works

- **IDs everywhere.** A description returns blank or 0 without any error.
- **Pin dimensions explicitly.** Unpinned ones follow the data source filter, and GETDATA cells
  only pick up a filter change after **Refresh → Refresh Sheet Functions**.
- **Several tables in one string:** `"Table1, Table2"`, not `("Table1","Table2")`.
- **TIMEOFFSET** takes a comma-separated *offsets* string, needs a **time hierarchy**, and doesn't
  work on BW or S/4HANA sources. A native `EDATE` axis works on any source.
- **SETDATA:** named dimensions must be **leaf**; combinations must be **unique**; then Process
  Data → Publish. One model plans at a time.
- **No IFERROR around data cells.** It can catch the pending state and leave a blank. Guard with
  `IF(input="",…)` instead, and keep one unwrapped test cell.
- **No volatile functions** (`NOW`, `TODAY`, `OFFSET`, `INDIRECT`, `RAND`, `INFO`, `CELL`) near SAP
  formulas. Point formulas at a **value** cell holding the table name, not at the
  GETTABLENAME cell. Turn on **Optimize Data Retrieval** when there are many formula cells.
- **Store numeric-looking IDs as text** (`'00'`, `'001'`) in lookup lists.
- **Generated formulas don't bind by themselves.** Text written by a tool opens as `#NAME?` until
  it is bound (clone a donor's metadata; see workbook-engineering). Never re-save a connected
  workbook with openpyxl.

## Core snippets

```
Asymmetric cell      =SAP.GETDATA(Ctl!$B$3,"Account",$A5,"Date",C$3,"Version",Ctl!$B$4)
Repointable cell     =SAP.GETDATA(Ctl!$B$3,Ctl!$B$10,$A5,Ctl!$B$11,C$3,Ctl!$B$12,Ctl!$B$4)
Guarded optional     =IF(Ctl!$B$6="",0,SAP.GETDATA(Ctl!$B$3,"Entity",Ctl!$B$6,"Account",$A5))
Rolling header       =SAP.TIMEOFFSET(Ctl!$B$3,Ctl!$B$5,"-11,-10,-9,-8,-7,-6,-5,-4,-3,-2,-1,0",0,1)
Native rolling axis  =TEXT(EDATE(DATE(LEFT(a,4),MID(a,5,2),1),SEQUENCE(1,12,-11)),"yyyymm")
Dropdown → tables    =SAP.OVERWRITEDIMENSIONFILTER("Table1, Table2","Region",Ctl!$B$6,4,0)
Filter button        =SAP.GETDIMENSIONFILTER("Table1","CostCenter",3,1,0)
Actual+Forecast      =SAP.ASYMMETRICFILTER("Table1",SAP.BLOCK("Version","public.Actual","Date",H4#),K20#)
Write-back           =SAP.SETDATA(Ctl!$B$3,D8,"Version",Ctl!$B$4,"Account",$A8,"CostCenter",Ctl!$B$5,"Date",D$7)
Attributes           =SAP.MEMBERPROPERTY(Ctl!$B$3,"CostCenter",A5:A60,"Description, Currency",0)
Comment + value      =SAP.GETDATACOMMENT(Ctl!$B$3,1,"Account",$A5,"Date",Ctl!$B$5)
Status banner        =SAP.GETTABLESTATUS("Table1, Table2",4)
Dimension IDs        =SAP.GETDIMENSIONS(Ctl!$B$3,0,0,1)
Run panel            =SAP.GETPLANNINGTRIGGERPARAMETERVALUE(SAP.GETPLANNINGTRIGGERNAME(B2),"TargetVersion",1,0)
```

## Reference files

- `references/function-reference.md`: every function, every option code, behaviours, wrong
  names, the AfO/EPM mapping, and release notes.
- `references/patterns.md`: 16 reporting, filter, time and metadata patterns.
- `references/planning.md`: the SETDATA rules, process → publish workflow, planning area,
  input-form, driver, allocation and bulk-load patterns, data/multi action triggers, VBA, and a
  planning checklist.
- `references/report-architecture.md`: intake questions, data source anchor + Control sheet,
  layout conventions, column engines, sizing, getting the real IDs, delivery modes.
- `references/workbook-engineering.md`: binding generated workbooks (`_xldudf_` + cloned
  metadata), zip surgery, reading the saved state, migration order, repair playbook,
  verification.
- `references/troubleshooting.md`: symptom → cause table, debugging routine, SAP notes.

## Scripts

- `scripts/build_formula.py`: builds any of the 16 functions with correct quoting and option
  checks; the `grid` subcommand emits a whole formula block (CSV/TSV); `--sep ";"` for European
  list separators.
- `scripts/sac_xlsx_tools.py`:
  - `inspect` reads the add-in's saved state (dimension IDs, filters, sources) and counts formulas.
  - `profile-donor` reads a donor's binding parts and its `cm`/`vm` indices.
  - `bind` makes generated `SAP.*` formulas bind by cloning a donor's metadata, with optional
    IFERROR stripping.
  - `verify` runs the pre-ship checklist and exits non-zero on failure.

Python 3.8+, standard library only.

When a signature here disagrees with the add-in's own function dialog (**fx → SAP Analytics
Cloud**), follow the dialog. SAP updates the add-in often.
