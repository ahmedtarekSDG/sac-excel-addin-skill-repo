# SAP Analytics Cloud add-in for Excel: function reference

The add-in has **16 functions** in the *SAP Analytics Cloud* category of Excel's function picker
(**fx → Select a category → SAP Analytics Cloud**). This page gives the exact argument order,
every documented option code, and the behaviours that decide whether a formula works.

> **The add-in is the final authority.** SAP ships the add-in every few weeks. If an argument here
> does not match what the add-in's function dialog shows, go with the dialog and report the difference.

## Contents
- [Conventions](#conventions)
- [Shared option codes](#shared-option-codes)
- **Data:** [GETDATA](#sapgetdata) · [SETDATA](#sapsetdata) · [GETDATACOMMENT](#sapgetdatacomment)
- **Filters and time:** [GETDIMENSIONFILTER](#sapgetdimensionfilter) · [OVERWRITEDIMENSIONFILTER](#sapoverwritedimensionfilter) · [ASYMMETRICFILTER](#sapasymmetricfilter) · [BLOCK](#sapblock) · [TIMEOFFSET](#saptimeoffset)
- **Metadata:** [GETTABLENAME](#sapgettablename) · [GETTABLESTATUS](#sapgettablestatus) · [GETDIMENSIONS](#sapgetdimensions) · [GETVARIABLES](#sapgetvariables) · [MEMBERPROPERTY](#sapmemberproperty)
- **Planning triggers:** [GETPLANNINGTRIGGERNAME](#sapgetplanningtriggername) · [GETPLANNINGTRIGGERPARAMETERS](#sapgetplanningtriggerparameters) · [GETPLANNINGTRIGGERPARAMETERVALUE](#sapgetplanningtriggerparametervalue)
- [Functions that do NOT exist in this add-in](#functions-that-do-not-exist-in-this-add-in)
- [Migrating from Analysis for Office / BPC EPM](#migrating-from-analysis-for-office--bpc-epm)
- [Release notes that matter for formulas](#release-notes-that-matter-for-formulas)

---

## Conventions

- **`Table`** is the first argument of almost every function. It is either:
  - the name of a **table** inserted on a sheet (`"Table1"`, `"Table2"`, … or a renamed name), or
  - the alias of a **data source for formulas** (`"DS_1"`, `"DS_2"`, …). You add one with
    *Designer → Add Data Source for Formulas*. It needs **no table on any sheet**, and it inserts
    `=SAP.GETDATA(DS_1)` into the selected cell.

  You can pass the name as a quoted literal or as a cell reference. A cell reference is better
  because a rename then becomes a one-cell edit. If you rename a table, Excel renames its named
  range, but literal names inside formulas are **not** updated.
- **List separator.** Arguments are separated by your Excel locale's list separator: `,` in
  most English locales, `;` in many European ones. SAP's own examples use both. The formulas on
  this page use `,`.
- **IDs, not descriptions.** `GETDATA`, `SETDATA` and `GETDATACOMMENT` need **dimension IDs** and
  **member IDs**: `"public.Actual"`, not `"Actual"`; `"202501"`, not `"Jan 2025"`; `"1000"`, not
  `"Head Office"`. Filter functions take a `Member_display` code that says how you wrote the members.
- **Spills.** The list-returning functions return dynamic arrays and spill into neighbouring
  cells: GETDIMENSIONFILTER, GETDIMENSIONS, GETVARIABLES, MEMBERPROPERTY, TIMEOFFSET, BLOCK and the
  trigger parameter functions. Keep the spill area empty (otherwise `#SPILL!`). Reference the
  result with the spill operator, e.g. `B5#`.
- **Asynchronous.** Data functions calculate in the background and show a pending state first.
  Don't build logic that reads the pending state (see *IFERROR* in `troubleshooting.md`).
- **Refreshing.** After you change a filter, refresh the formulas: **Refresh → Refresh Sheet
  Functions** (current sheet), or Refresh All.

## Shared option codes

| Code | `Display` / `Member_display` (most functions) | `Orientation` |
|---|---|---|
| 0 | ID | vertical |
| 1 | Description | horizontal |
| 2 | ID and description | — |
| 3 | Description and ID | — |
| 4 | Full ID (unique name, e.g. `[Dim].[Hier].&[Member]`) | — |
| 5 | ID and description in two cells (GETDIMENSIONFILTER only) | — |
| 6 | Description and ID in two cells (GETDIMENSIONFILTER only) | — |

⚠️ **The default orientation is not the same everywhere.** GETDIMENSIONFILTER and GETDIMENSIONS
default to *vertical* (0). TIMEOFFSET and GETVARIABLES default to *horizontal* (1). Always pass
Orientation explicitly.

---

## Data

### SAP.GETDATA
```
=SAP.GETDATA(Table, Dimension1, Member1, [Dimension2, Member2], …)
```
Returns the value for one dimension/member combination. Asymmetric reports are built from it.

- **Pairs.** Give a dimension ID followed by a member ID. You may include the measure dimension
  (e.g. `"Account","Revenue"` in an account model, or the measure/key-figure dimension in a
  measure model) and any number of other pairs.
- **Dimensions you leave out** take the member set in the **filter of that data source** (in
  the panel). Dimensions that aren't in the panel use the backend default. This means a formula
  can return a different number when someone changes the table filter. Pin every dimension the
  number depends on (see `report-architecture.md`).
- **"All members" is not a member.** The virtual *All members* entry can't be used. To mean
  "everything", leave the dimension out and keep its filter unrestricted, or pass the real ID of
  the hierarchy's root node. Never pass `""` to mean "all": blank means *unassigned/none*.
- **Filter changes don't recalculate existing GETDATA cells.** Refresh the sheet functions.
- **Formatting.** With a table as the source, the table's default format is applied (you can
  turn off *Apply Default Format* in the data-source context menu). A data source for formulas
  uses its own predefined format.
- **Offline.** In offline mode (preference *Mode for Data Formulas*), GETDATA keeps showing the
  last calculated value.
- **Comments.** You can view and create data point comments on valid GETDATA/SETDATA cells.
- **Performance.** For workbooks with many GETDATA/SETDATA cells, turn on *Workbook Preferences →
  Optimize Data Retrieval* (SAP KBA 3783562).

```
=SAP.GETDATA("DS_1","Account","Revenue","Date","202501","Version","public.Actual")
=SAP.GETDATA($B$1,"Account",$A5,"Date",C$3,"Version",$B$2)          ' fills across/down
=SAP.GETDATA(Ctl!$B$3, Ctl!$B$10,$A5, Ctl!$B$11,C$3)                  ' dimension IDs from cells
```

### SAP.SETDATA
```
=SAP.SETDATA(Table, Value, Dimension1, Member1, [Dimension2, Member2], …)
```
Writes `Value` back to a planning-enabled model at the given combination.

- `Value` can be a number, a cell, or an expression. If you don't supply a new value, the
  function behaves like GETDATA and shows the current value.
- After a value changes, choose **Process Data** to submit it, then **Publish Data** (or Revert).
  See `planning.md`.
- **Hierarchies.** Every dimension you *name* in the formula must be given a **leaf** member.
  Dimensions you leave out take the panel filter, and that filter *can* be a node, which is the
  only way to post at node level from a formula.
- **Duplicates.** If two SETDATA formulas point at the same combination, only one value is kept
  (community testing shows the highest one). Aggregate duplicates before writing.
- **Planning area.** A SETDATA write outside the current planning area extends the area, so you
  don't need to publish first (release 2025.01).
- **Known issue.** If you change table cells and SETDATA inputs and then process both together,
  the first *Process Data* can skip the SETDATA values. Process again (SAP KBA 3763022).

```
=SAP.SETDATA("DS_1", D5, "Version","public.Plan","Account","OPEX_TRAVEL","CostCenter","CC100","Date","202601")
=SAP.SETDATA($B$1, C8*C9, "Version",$B$2,"Account","REVENUE","Product",$A8,"Date",D$3)
```

### SAP.GETDATACOMMENT
```
=SAP.GETDATACOMMENT(Table, Display, Dimension1, Member1, [Dimension2, Member2], …)
```
Returns the **last** comment in the comment thread at a combination. It can also return the
data value next to the comment.

- **`Display` is the 2nd argument:**
  - 0: comment only (default)
  - 1: value left, comment right
  - 2: comment left, value right
  - 3: value above comment
  - 4: comment above value
- Needs data point commenting enabled, and the source must be an **SAP Analytics Cloud model**.
- Dimensions you leave out follow the same filter rules as GETDATA.

```
=SAP.GETDATACOMMENT("Table1", 1, "Account","Revenue","Product","P100","Date","202512")
```

---

## Filters and time

### SAP.GETDIMENSIONFILTER
```
=SAP.GETDIMENSIONFILTER(Table, Dimension, [Member_display], [Selection_display], [Orientation], [Separator])
```
Shows the current filter of a dimension, with a **pencil icon** that opens the add-in's filter
dialog on the sheet. You get a filter control without opening the Designer panel.

- `Member_display` 0–6. Default 2 (ID and description).
- `Selection_display` 0–3, or 4 = show nothing (default). This controls the selection-type label,
  e.g. "Self and Descendants".
- `Orientation` 0 vertical (default), 1 horizontal.
- `Separator` is the text placed between ID and description.

```
=SAP.GETDIMENSIONFILTER("Table1","Product",3,1,0)
=SAP.GETDIMENSIONFILTER(Ctl!$B$3,"Date",0,4,1)       ' IDs only, horizontal → feed other formulas
```

### SAP.OVERWRITEDIMENSIONFILTER
```
=SAP.OVERWRITEDIMENSIONFILTER(Tables, Dimension, Members, [Selection_type], [Member_display], [Separator])
```
Replaces the selected members of a dimension on one or more tables or formula data sources, and
returns the new filter (displayed with IDs). Refresh the affected tables or formulas to apply it.

- **`Tables`**: one name, a comma-separated list **inside one string** (`"Table1, Table2"`),
  or a range of cells holding names. *(Not `("Table1","Table2")`.)*
- **`Members`**: a single member, a list, or a range or spill reference (`A9#`) from the sheet.
  To filter on several members, reference them from cells.
- **`Selection_type`** (you can also take it from a cell):
  - 0: Self and Descendants (default)
  - 1: Descendants only
  - 2: Self and Children
  - 3: Children only
  - 4: Self only
  - 5: Leaf members only

  With 2 (Self and Children), only the first member and its children are applied, even if you
  listed more members.
- **`Member_display`** must match how `Members` is written: 0 ID, 1 description, 2 ID and
  description, 3 description and ID, 4 full ID. Prefer **0 with IDs**: descriptions are not unique
  and break when text changes.
- **No range operator.** For a date range, build the list in Excel (see the patterns page:
  `SEQUENCE`) and pass the spill.

```
=SAP.OVERWRITEDIMENSIONFILTER("Table1","Product",$B$2,4,0)                    ' dropdown → table
=SAP.OVERWRITEDIMENSIONFILTER("Table1, Table2, DS_1","Region",$B$3,0,0)         ' one cell drives three sources
=SAP.OVERWRITEDIMENSIONFILTER(Ctl!$B$3,"Date",SAP.TIMEOFFSET(Ctl!$B$3,$B$4,"-11,-10,-9,-8,-7,-6,-5,-4,-3,-2,-1,0"),4,0)
```

### SAP.ASYMMETRICFILTER
```
=SAP.ASYMMETRICFILTER(Tables, Block1, [Block2], …)
```
Applies an **asymmetric filter** to tables: different member combinations for different parts
of the axis. A typical use is actuals for past months next to forecast for future months.

- `Tables` works as in OVERWRITEDIMENSIONFILTER.
- Each **block** is a two-column range of *dimension | member* rows (e.g. `F6:G9`), or the spill
  of an `SAP.BLOCK` formula (`A10#`).
- Refresh the table afterwards. SAP recommends putting a hierarchy dimension first on the axis
  and expanding its top node after the filter is applied.
- **Limitation:** doesn't work with time-related calculated measures such as YTD/QTD/MTD
  (SAP KBA 3639646).

```
=SAP.ASYMMETRICFILTER("Table1", F6:G9, A10#)
```

### SAP.BLOCK
```
=SAP.BLOCK(Dimension1, Member(s)1, [Dimension2, Member(s)2], … up to 5 pairs)
```
Builds a block (a spilled two-column list of dimension/member rows) to use in ASYMMETRICFILTER.
There is **no `Table` argument**. Each member argument can be one member, a list, or a range.

```
=SAP.BLOCK("Version","public.Actual","Date",G4:G8)        ' Actual × 5 months
=SAP.BLOCK("Version","public.Forecast","Date",H4#)        ' Forecast × spilled future months
```

### SAP.TIMEOFFSET
```
=SAP.TIMEOFFSET(Table, Reference_date, Offsets, [Display], [Orientation], [Dimension])
```
Returns time members relative to a reference member. It spills one result per offset.

- `Reference_date`: a member ID of the time dimension (`"2025"`, `"202506"`, …) or a cell.
  Use the ID format of the **level** you want back.
- `Offsets`: comma-separated text, e.g. `"-1, 0, 1, 2"` or `"-11,-10,…,0"`, or a cell holding it.
- `Display`: 0 ID (default), 1 description, 2 ID and description (two cells), 3 description and
  ID (two cells).
- `Orientation`: 0 vertical, **1 horizontal (default)**.
- `Dimension`: optional. Use it for a time dimension other than the data source's default.
- **Restrictions:** only works on a **hierarchy** (not on flat lists), and doesn't work for
  **SAP BW** or **SAP S/4HANA** data sources.

```
=SAP.TIMEOFFSET("Table1","2022","-1, 0, 1, 2")              → 2021 | 2022 | 2023 | 2024
=SAP.TIMEOFFSET($B$1,$B$4,"-11,-10,-9,-8,-7,-6,-5,-4,-3,-2,-1,0",0,1)   ' 12-month header row
```
> Older notes (and earlier versions of this skill) showed `SAP.TIMEOFFSET(DS, "Date", member, -12)`.
> **That signature is wrong.** If TIMEOFFSET can't be used (flat time, BW/S4 source), build the
> axis with native Excel: `=TEXT(EDATE(DATE(LEFT(a,4),MID(a,5,2),1),k),"yyyymm")`.

---

## Metadata

### SAP.GETTABLENAME
```
=SAP.GETTABLENAME(Cell)
```
Returns the name of the table that contains `Cell`.
**Performance tip from SAP:** don't point hundreds of formulas at the cell that holds
`GETTABLENAME`. Copy its result into a plain value cell (e.g. `Ctl!$B$3 = "Table1"`) and
reference that. Keep the GETTABLENAME cell as a check.

### SAP.GETTABLESTATUS
```
=SAP.GETTABLESTATUS(Tables, [Display])
```
Returns the refresh status of one or more tables (`"Table1, Table2"`). `Display` is 0–4.
**4 = table name, status and status message**. Codes 0–3 show subsets; check the function
dialog for each one. Good for a status banner.

### SAP.GETDIMENSIONS
```
=SAP.GETDIMENSIONS(Table, [Display], [Orientation], [Sort_order])
```
Lists all dimensions of the data source.
- `Display` 0–4 (default 2).
- `Orientation` 0 vertical (default) or 1 horizontal.
- `Sort_order` 0 none (default), 1 ascending, 2 descending.

```
=SAP.GETDIMENSIONS("Table1",0,0,1)     ' dimension IDs, vertical, A→Z (use this to copy the real IDs)
```

### SAP.GETVARIABLES
```
=SAP.GETVARIABLES(Table, Variable, [Variable_display], [Value_display], [Layout], [Orientation])
```
Returns the values set for a data source's variables (prompts).
- `Variable_display`: 0 ID, 1 description (default).
- `Value_display`: 0 ID (default), 1 description. If a value has no description, its ID is shown.
- `Layout`: 2 = all values in **one cell** without the variable name (separated by line breaks);
  3 = values in **separate cells** without the variable name. Lower codes include the variable;
  check the function dialog.
- `Orientation`: 0 vertical, 1 horizontal (default).

```
=SAP.GETVARIABLES("Table1","City",1,1,3,0)
```

### SAP.MEMBERPROPERTY
```
=SAP.MEMBERPROPERTY(Table, Dimension, Members, Properties, [Orientation])
```
Returns one or more property (attribute) values for one or more members.
- `Members`: a member, a list, a cell or a **range**. For speed, SAP recommends **one
  MEMBERPROPERTY formula per dimension with a range**, not one per row.
- `Properties`: comma-separated, as listed in the function dialog
  (e.g. `"Description, Country (Short_Text)"`).
- A missing property shows as blank. Works in **offline mode** (release 2026.07).

```
=SAP.MEMBERPROPERTY("Table1","CostCenter",A5:A40,"Description, Currency",0)
```

---

## Planning triggers

Add data action or multi action triggers to cells first (**ribbon → Planning Triggers**). These
functions then read and edit the trigger's parameters from the sheet. They work for **data
action triggers** and, since release 2026.19, **multi action triggers**.

### SAP.GETPLANNINGTRIGGERNAME
```
=SAP.GETPLANNINGTRIGGERNAME(Cell)
```
Returns the name of the planning trigger in `Cell`.

### SAP.GETPLANNINGTRIGGERPARAMETERS
```
=SAP.GETPLANNINGTRIGGERPARAMETERS(Planning_trigger, [Display], [Orientation])
```
Lists all parameters of the trigger (spills).

### SAP.GETPLANNINGTRIGGERPARAMETERVALUE
```
=SAP.GETPLANNINGTRIGGERPARAMETERVALUE(Planning_trigger, Parameter, [Display], [Orientation])
```
Lists the current value(s) of one parameter, with a **pencil icon** that opens a dialog to change
them on the sheet. `Display` 0 ID, 1 description, 2 ID and description (default), 3 description
and ID.

```
B3: =SAP.GETPLANNINGTRIGGERNAME(B2)                       ' B2 holds the trigger
B5: =SAP.GETPLANNINGTRIGGERPARAMETERS(B3,1,0)
B9: =SAP.GETPLANNINGTRIGGERPARAMETERVALUE(B3,"TargetVersion",1,0)
```

---

## Functions that do NOT exist in this add-in

These names show up in blogs, AI answers and old notes, including earlier versions of this
skill. They are **not** add-in functions and return `#NAME?`:

| Wrong name | Use instead |
|---|---|
| `SAP.GETMEMBERS` | A small helper **table** with the dimension on rows (ID display); `SAP.GETDIMENSIONFILTER(...,0,4,0)` to list the current filter's members; a master-data export on a `_Lists` sheet; `SAP.MEMBERPROPERTY` to add attributes to a list you already have |
| `SAP.GETMESSAGE` | `SAP.GETTABLESTATUS(Tables,4)` for table status and messages; the add-in's message area; a visible, **unwrapped** test GETDATA cell |
| `SAP.GETDATASOURCE`, `SAP.SETFILTER`, `SAP.GETMEMBER` | Analysis for Office / EPM names. See the mapping below |

## Migrating from Analysis for Office / BPC EPM

| Analysis for Office / EPM | SAC add-in equivalent |
|---|---|
| `SAPGetData`, `EPMRetrieveData` | `SAP.GETDATA` |
| `EPMSendData` / input-ready query cells | `SAP.SETDATA` + Process Data |
| `SAPSetFilter`, `EPMDimensionOverride` | `SAP.OVERWRITEDIMENSIONFILTER` |
| `SAPGetMember` / `EPMMemberProperty` | `SAP.MEMBERPROPERTY` |
| `SAPGetVariable` | `SAP.GETVARIABLES` |
| `SAPGetDimensionInfo` | `SAP.GETDIMENSIONS` |
| `EPMMemberOffset` | `SAP.TIMEOFFSET` |
| Planning sequence / function buttons | Data action / multi action triggers + trigger formulas |

The concepts carry over but the syntax doesn't: always rebuild the arguments using the signatures above.

## Release notes that matter for formulas

| Release | Change |
|---|---|
| 2023.13 | `SAP.SETDATA` write-back released |
| 2023 | *Add Data Source for Formulas* (formulas without a table); several tables per workbook |
| 2025.01 | SETDATA can extend the planning area |
| 2025 Q2 | VBA API for the add-in (`SAPOFXLA.xlam`, SAP Note 3594453) |
| late 2025 | Data point comments in Excel; `SAP.GETDATACOMMENT` |
| 2026.07 | `SAP.MEMBERPROPERTY` works offline |
| 2026.09 | Data action trigger parameters can use the default value defined in SAC |
| 2026.11 | Formula data source aliases can be renamed |
| 2026.13 | *Optimize Data Retrieval* preference for GETDATA/SETDATA performance |
| 2026.19 | Multi action triggers (Member, Number, String, Date, Time parameters + Validate); restricted measures on formula data sources |

For anything newer, check *What's New in SAP Analytics Cloud, add-in for Microsoft Excel* on the SAP Help Portal.
