# Reporting, filter, time and metadata patterns

Ready-to-adapt patterns for the add-in's formulas. All of them are business-neutral: swap in
your own dimension and member IDs. Planning patterns are in `planning.md`. Whole-workbook
architecture is in `report-architecture.md`.

Every example reads its parameters from a small Control sheet named **`Ctl`**:

| Cell | Example value | Meaning |
|---|---|---|
| `Ctl!B3` | `DS_1` | Data source: table name or formula data source alias (plain value) |
| `Ctl!B4` | `public.Plan` | Version ID used for plan / comparison columns |
| `Ctl!B5` | `202506` | Anchor period: the latest closed period |
| `Ctl!B6` | `CC100` | Selected member ID (entity, cost center, region …), resolved from a dropdown |
| `Ctl!B7` | `202601` | Planning period |
| `Ctl!B8` | `=TEXT(EDATE(DATE(LEFT(B5,4),MID(B5,5,2),1),-12),"yyyymm")` | Prior-year period (derived) |
| `Ctl!B9` | `=TEXTJOIN(",",,SEQUENCE(1,12,-11))` | Offsets text for TIMEOFFSET (`-11,…,0`) |
| `Ctl!B10:B13` | `Account` · `Date` · `Version` · `Entity` | Dimension IDs, for repointable formulas |
| `Ctl!B14` | `500` | Variance threshold for exception flags |

Production workbooks use the fuller layout in `report-architecture.md` §2. Any cell address works,
as long as formulas point at the Control cells rather than at literals.

## Contents
1. Asymmetric report without a table (formula data source)
2. Parameterized grid (dimension IDs in cells)
3. Actual vs. plan vs. prior year with variances
4. Rolling N periods: TIMEOFFSET header
5. Rolling N periods: native Excel axis (fast, works on any source)
6. Period views from the model (MTD / QTD / YTD)
7. One dropdown drives several tables
8. On-sheet filter button
9. Date-range filter
10. Rolling actual + forecast table (asymmetric filter)
11. Several members summed (multi-select)
12. Blending two sources
13. Master data enrichment
14. Commentary / exception report
15. Status banner and model explorer
16. KPI cards / dashboard tiles

---

## 1. Asymmetric report without a table
*Designer → Add Data Source for Formulas* creates alias `DS_1` and puts `=SAP.GETDATA(DS_1)` in
the cell. No table is inserted. Then lay out any grid you like:
```
B1  DS_1                                   (plain value; rename-safe if referenced)
A5  REVENUE     A6  COGS     A7  OPEX      (account IDs)
C3  202501      D3  202502   …             (period IDs)
C5  =SAP.GETDATA($B$1,"Account",$A5,"Date",C$3,"Version","public.Actual")   → fill C5:N7
```
Mixed `$` anchoring (`$A5`, `C$3`) lets one formula fill the whole block.

## 2. Parameterized grid (repointable)
Both the **dimension** argument and the **member** argument accept cell references. Put the
dimension IDs in cells and every formula follows when the model changes:
```
Ctl!B10 Account      Ctl!B11 Date      Ctl!B12 Version      Ctl!B13 Entity   (dimension IDs)
C5 =SAP.GETDATA(Ctl!$B$3, Ctl!$B$10,$A5, Ctl!$B$11,C$3, Ctl!$B$12,Ctl!$B$4, Ctl!$B$13,Ctl!$B$6)
```
Pointing the report at another model then means editing a few cells on Ctl. It also absorbs
SAC-side ID renames (e.g. a truncated `_FINANCIAL_STATEMEN1`).

## 3. Actual vs. plan vs. prior year
```
C: Actual   =SAP.GETDATA(Ctl!$B$3,"Account",$A5,"Date",Ctl!$B$5,"Version","public.Actual")
D: Plan     =SAP.GETDATA(Ctl!$B$3,"Account",$A5,"Date",Ctl!$B$5,"Version",Ctl!$B$4)
E: PY       =SAP.GETDATA(Ctl!$B$3,"Account",$A5,"Date",Ctl!$B$8,"Version","public.Actual")
F: Δ Plan   =C5-D5                  G: Δ% =IF(D5=0,"",F5/ABS(D5))
H: Δ PY     =C5-E5                  I: Δ% =IF(E5=0,"",H5/ABS(E5))
Ctl!B8 (PY period) =TEXT(EDATE(DATE(LEFT(Ctl!B5,4),MID(Ctl!B5,5,2),1),-12),"yyyymm")
```
Variances and percentages are **native Excel**, never extra GETDATA calls.

## 4. Rolling N periods: TIMEOFFSET header
`SAP.TIMEOFFSET` spills the periods. Horizontal is the default.
```
C3  =SAP.TIMEOFFSET(Ctl!$B$3, Ctl!$B$5, "-11,-10,-9,-8,-7,-6,-5,-4,-3,-2,-1,0", 0, 1)   → C3:N3 period IDs
C2  =SAP.TIMEOFFSET(Ctl!$B$3, Ctl!$B$5, "-11,-10,-9,-8,-7,-6,-5,-4,-3,-2,-1,0", 1, 1)   → labels
C5  =SAP.GETDATA(Ctl!$B$3,"Account",$A5,"Date",C$3,"Version","public.Actual")
```
Build the offset text with a formula: `=TEXTJOIN(",",,SEQUENCE(1,12,-11))`.
**Limits:** the time dimension must be a hierarchy, and BW or S/4HANA sources are not supported.

## 5. Rolling N periods: native Excel axis
Faster (no asynchronous call) and works on any source, including flat time and BW/S4:
```
C3  =TEXT(EDATE(DATE(LEFT(Ctl!$B$5,4),MID(Ctl!$B$5,5,2),1), COLUMN()-COLUMN($N$3)),"yyyymm")
C2  =TEXT(EDATE(DATE(LEFT(Ctl!$B$5,4),MID(Ctl!$B$5,5,2),1), COLUMN()-COLUMN($N$3)),"mmm-yy")
```
Or spill the whole axis in one cell: `=TEXT(EDATE(DATE(LEFT(a,4),MID(a,5,2),1),SEQUENCE(1,12,-11)),"yyyymm")`.
Match the model's period ID format exactly (`yyyymm`, `yyyy-mm`, `yyyy0mm` fiscal, …). Check one
period with a test GETDATA first.

## 6. Period views from the model (MTD / QTD / YTD)
If the model has a **view dimension** (e.g. `PERIOD_VIEW` with members `MTD`, `QTD`, `YTD`, and
optionally a year view `CY`/`PY`), let the model do the time maths: one GETDATA per cell, and no
running sums in Excel.
```
P&L month column   …,"PERIOD_VIEW","MTD",…
P&L YTD column     …,"PERIOD_VIEW","YTD",…
Balance sheet      …,"PERIOD_VIEW","YTD",…       (a balance is a cumulative position)
```
With fiscal year + period dimensions, derive both from one `yyyymm` cell:
`"FISCAL_YEAR",LEFT(m,4),"FISCAL_PERIOD","0"&MID(m,5,2)`. If period `000` holds the carry-forward
or opening balance, a YTD balance includes it.

## 7. One dropdown drives several tables
```
Ctl!B6  (Data Validation list → _Lists!A2:A40 of IDs, or description list + resolver)
B2      =SAP.OVERWRITEDIMENSIONFILTER("Table1, Table2, DS_1","Region",Ctl!$B$6,4,0)
```
- Several sources go in **one string**, separated by commas, or in a range of names.
- Selection type `4` = Self only, `0` = Self and descendants (useful for a hierarchy node).
- After the filter changes, refresh the tables and *Refresh Sheet Functions*.
- **Dropdown lists:** there is no GETMEMBERS function. Source the list from a hidden helper table
  with the dimension on rows (ID display), a master-data export on `_Lists`, or the IDs spilled
  by `SAP.GETDIMENSIONFILTER(tbl,dim,0,4,0)` on a helper table whose filter selects exactly the
  members you want to offer.
- **Description dropdown → ID:** `=INDEX(_Lists!$B:$B, MATCH(Ctl!$B$6,_Lists!$A:$A,0))`. Pass the
  **ID** on, never the description.

## 8. On-sheet filter button
```
B2  =SAP.GETDIMENSIONFILTER("Table1","CostCenter",3,1,0)
```
Shows the current selection with a pencil icon. Clicking it opens the add-in's member selector,
so business users never need the Designer panel.

## 9. Date-range filter
There's no BETWEEN operator. Generate the list in Excel and pass the spill:
```
D3  start date      D4  end date
A9  =TEXT(D3+SEQUENCE(1+D4-D3,,0),"yyyy-mm-dd")         ' inclusive list of day IDs
B2  =SAP.OVERWRITEDIMENSIONFILTER(Ctl!$B$3,"Ship_Date",A9#,4,0)
```
Monthly version: `=TEXT(EDATE(D3,SEQUENCE(DATEDIF(D3,D4,"m")+1,,0)),"yyyymm")`.

## 10. Rolling actual + forecast table (asymmetric filter)
```
H4  =SAP.TIMEOFFSET(Ctl!$B$3,Ctl!$B$5,"-5,-4,-3,-2,-1,0",0,0)      ' past 6 (vertical)
I4  =SAP.TIMEOFFSET(Ctl!$B$3,Ctl!$B$5,"1,2,3,4,5,6",0,0)            ' next 6
K4  =SAP.BLOCK("Version","public.Actual","Date",H4#)
K20 =SAP.BLOCK("Version","public.Forecast","Date",I4#)
B2  =SAP.ASYMMETRICFILTER("Table1",K4#,K20#)
```
The table needs Version and Date on the column axis. Put the hierarchy dimension first and
expand its top node. This doesn't work with YTD/QTD/MTD calculated measures.

## 11. Several members summed (multi-select)
Each dimension/member pair takes **one** member. To add up several, either:
- pass a **hierarchy node** that rolls them up (cleanest), or
- add up guarded calls:
```
=IF(Ctl!$B$21="",0,SAP.GETDATA(Ctl!$B$3,"Entity",Ctl!$B$21,"Account",$A5,"Date",C$3))
+IF(Ctl!$B$22="",0,SAP.GETDATA(Ctl!$B$3,"Entity",Ctl!$B$22,"Account",$A5,"Date",C$3))
```
In consolidation models, a unit's value **within a group** can differ from its standalone value
because of eliminations. Pin the group dimension explicitly.

## 12. Blending two sources
Add one source per model (`DS_1` = SAC planning model, `DS_2` = Datasphere actuals). Put their
GETDATA cells side by side and calculate with plain Excel:
```
C5 =SAP.GETDATA("DS_2","Account",$A5,"Date",C$3)                         ' actuals (Datasphere)
D5 =SAP.GETDATA("DS_1","Account",$A5,"Date",C$3,"Version","public.Plan")  ' plan (SAC)
E5 =C5-D5
```
The two models may use different dimension and member IDs. Keep a mapping column (`$B5`)
for the second model's IDs.

## 13. Master data enrichment
```
A5:A60  cost center IDs
B5      =SAP.MEMBERPROPERTY(Ctl!$B$3,"CostCenter",A5:A60,"Description, Currency, Manager",0)   → spills 3 columns
```
Use **one formula per dimension with a range**, as SAP recommends for performance. It works offline.
Use it instead of local VLOOKUP master-data tables.

## 14. Commentary / exception report
```
E5 =SAP.GETDATACOMMENT(Ctl!$B$3,1,"Account",$A5,"Date",Ctl!$B$5,"Version",Ctl!$B$4)   ' E5 value, spills comment into F5
G5 =E5-D5                                                                               ' Δ vs plan
H5 =IF(AND(ABS(G5)>Ctl!$B$14, F5=""),"⚠ variance not explained","")
```
Data point commenting must be enabled, and the source must be an SAC model.

## 15. Status banner and model explorer
```
B1  =SAP.GETTABLESTATUS("Table1, Table2",4)        ' name | status | message per table
A10 =SAP.GETDIMENSIONS(Ctl!$B$3,0,0,1)             ' every dimension ID, A→Z: copy the real IDs from here
D10 =SAP.GETVARIABLES(Ctl!$B$3,"<variable>",1,1,3,0)
```
Put the explorer on a hidden `_Meta` sheet. It's the fastest way to get exact dimension IDs.

## 16. KPI cards / dashboard tiles
Lay out cards in merged cells, one GETDATA per card, and native Excel for deltas and sparklines:
```
B3 =SAP.GETDATA(Ctl!$B$3,"Account","REVENUE","Date",Ctl!$B$5,"Version","public.Actual")
B4 =B3/SAP.GETDATA(Ctl!$B$3,"Account","REVENUE","Date",Ctl!$B$8,"Version","public.Actual")-1
B5 (sparkline over a hidden 12-month GETDATA strip built with pattern 5)
```
