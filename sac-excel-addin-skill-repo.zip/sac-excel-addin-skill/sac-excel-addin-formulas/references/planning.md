# Planning with the SAC add-in: SETDATA, the planning workflow and triggers

Read this for any **write-back** task: input forms, driver-based plans, allocations calculated
in Excel, bulk loads, rolling forecasts, or running data actions and multi actions from Excel.

## Contents
1. Prerequisites and ground rules
2. The planning workflow (enter → process → publish)
3. Table input vs. SETDATA input
4. SETDATA design rules
5. Planning patterns (with formulas)
6. Data action and multi action triggers
7. VBA for guided flows
8. Planning checklist and error decoder

---

## 1. Prerequisites and ground rules

- The model is a **planning-enabled SAC model**. Live Datasphere and S/4HANA sources are read-only.
- The user needs planning rights on the model and **write access to the version** (public edit
  mode or a private version).
- Planning is switched on per table or data source (*Builder panel → Planning → Planning
  Enabled*). This is also where *Optimize Planning Area* lives.
- **One model at a time.** While you plan on one model, the other tables are disabled and the
  Designer panel isn't available. To plan on another model, switch planning off on the first one.
- **Mass data entry is the default.** You can type many values; nothing goes to the backend until
  you choose **Process Data**.
- **Data locks:** the add-in doesn't show locked cells visually. Processing values on locked
  cells may work, but **publishing is refused**. Tell users which slices are locked.

## 2. The planning workflow

```
type values / SETDATA inputs change
        │
        ▼
 Process Data      → values are calculated in the workbook and sent to the version's edit area;
        │            the changed cells are highlighted
        ▼
 Refresh           → (all tables, if several) see disaggregations, totals, data action results
        │
        ▼
 Publish Data      → writes to the public version (others can see it)   or   Revert → discard
```

- **Version Management** (ribbon) handles publish, revert, *Publish As* and copying versions.
- **Planning area:** with *Recommended/Optimize Planning Area* only part of a version is put into
  edit mode, which is faster on big versions. A **SETDATA write outside the current area extends
  it** (release 2025.01), so you can keep planning without publishing first.
- **Node input in a table:** a value typed on a hierarchy **node** is spread proportionally across
  its unchanged children when you process.

## 3. Table input vs. SETDATA input

| | Typing into a planning-enabled table | `SAP.SETDATA` formula |
|---|---|---|
| Layout | Fixed by the table's axes | Any layout: forms, cards, mixed blocks |
| Node entry | Yes (proportional spread) | Named dimensions must be **leaf**; node only via the panel filter of an unnamed dimension |
| Driver logic | Only through table calculations | Any Excel expression (`=C8*C9`, `XLOOKUP`, …) |
| Volume | Large grids | Best for a few hundred to a few thousand cells. Turn on *Optimize Data Retrieval* |
| Risk | Users overtype totals | Duplicate combinations; formulas pointing at the wrong combination without anyone noticing |

**Mixing both in one Process step:** SAP KBA 3763022 describes the SETDATA values being skipped on
the first *Process Data* when table input and SETDATA input are processed together. Process a
second time, or process the two input types separately.

## 4. SETDATA design rules

1. **Spell out the full combination.** Name every dimension that isn't fixed by the data source's
   filter. Treat each SETDATA formula like one line of a flat-file load.
2. **Member IDs only**: `"public.Plan"`, not `"Plan"`.
3. **Leaf members** for every dimension you name. To post to a node, leave that dimension out
   of the formula and set the node in the data source's filter.
4. **Unique combinations.** If two formulas write the same combination, only one value is kept.
   For flat lists, build a key (`=A4&"|"&B4&"|"&C4`), add up values per key (`SUMIFS`), and give
   each key one SETDATA.
5. **Separate inputs from SETDATA cells.** The SETDATA cell shows the model's current value after
   refresh. Put the user's input in its own yellow cell and point SETDATA at it. That way, after a
   refresh, the input cell and the model value can be compared side by side (a reconciliation column).
6. **Read-back column.** Next to each SETDATA cell, add a GETDATA cell for the same combination.
   It proves the write landed and the coordinates are right.
7. **Guard empty inputs:** `=IF(D5="", SAP.GETDATA(<same coordinates>), SAP.SETDATA(<…>, D5, <…>))`
   only writes when the user typed something. Keep it simple, because many wrapped SETDATA cells
   are harder to audit.
8. **Scale carefully.** A few thousand SETDATA cells are fine with *Optimize Data Retrieval*. For
   tens of thousands, use a planning-enabled table, a data action, or a file import.

## 5. Planning patterns

### 5.1 Branded budget input form (OPEX by cost center)
```
Ctl!B3  DS alias              DS_1
Ctl!B4  Version ID            public.Budget2026
Ctl!B6  Cost center ID        CC100            (dropdown → ID resolver)
Row 8+  A: account ID  B: account name  C:N: Jan..Dec input (yellow)
Row 7   C7:N7  period IDs 202601..202612 (hidden helper row)

Write cell (P8, filled across and down to AA):
=SAP.SETDATA(Ctl!$B$3, C8, "Version",Ctl!$B$4, "CostCenter",Ctl!$B$6,
             "Account",$A8, "Date",C$7)
```
Process Data → check the read-back block → Publish Data.

### 5.2 Driver-based plan (price × volume)
```
C8  volume (input)       D8  price (input)       E8  =C8*D8
F8  =SAP.SETDATA(Ctl!$B$3, C8, "Version",Ctl!$B$4,"Account","SALES_QTY","Product",$A8,"Date",Ctl!$B$7)
G8  =SAP.SETDATA(Ctl!$B$3, E8, "Version",Ctl!$B$4,"Account","REVENUE","Product",$A8,"Date",Ctl!$B$7)
```
Write the **drivers and the result** only when the model has no calculation of its own.
Otherwise write the drivers and let model logic or a data action calculate the result.

### 5.3 Spread a yearly total in Excel (allocation by profile)
```
C5  annual target (input)      D4:O4  seasonality % (sums to 100%)
D5  =ROUND($C5*D$4,2)          (last month absorbs the rounding: =C5-SUM(D5:N5))
D6  =SAP.SETDATA(Ctl!$B$3, D5, …, "Date", D$3)
```

### 5.4 Bulk load from a flat list (paste, then write)
```
A:F  pasted lines (Version | Entity | Account | Product | Date | Value)
G    key   =A2&"|"&B2&"|"&C2&"|"&D2&"|"&E2
H    first =COUNTIF($G$2:G2,G2)=1
I    total =IF(H2, SUMIFS($F:$F,$G:$G,G2), "")
J    write =IF(H2, SAP.SETDATA(Ctl!$B$3, I2, "Version",A2,"Entity",B2,"Account",C2,"Product",D2,"Date",E2), "")
```

### 5.5 Rolling forecast table (actuals behind, forecast ahead)
Build two blocks and apply them with an asymmetric filter. Users then type the forecast into the
table.
```
H4#  = SAP.TIMEOFFSET(Ctl!$B$3, Ctl!$B$5, "-5,-4,-3,-2,-1,0", 0, 0)     ' last 6 actual months
I4#  = SAP.TIMEOFFSET(Ctl!$B$3, Ctl!$B$5, "1,2,3,4,5,6", 0, 0)          ' next 6 forecast months
K4   = SAP.BLOCK("Version","public.Actual","Date",H4#)
K20  = SAP.BLOCK("Version","public.Forecast","Date",I4#)
B2   = SAP.ASYMMETRICFILTER("Table1", K4#, K20#)
```
Change the anchor month in `Ctl!$B$5` and the window slides. Not compatible with YTD/QTD/MTD
calculated measures (KBA 3639646).

### 5.6 What-if sandbox
Point the version cell at a **private version**, let users write freely with SETDATA, compare
with GETDATA against the public version in a variance column, and publish (*Publish As*) only
the scenario that gets approved.

## 6. Data action and multi action triggers

**Add a trigger:** ribbon → **Planning Triggers** → *Data Action Trigger* or *Multi Action
Trigger*. Then configure it in the pane:
- Select the data action or multi action.
- Set the **parameters**. Data actions support member, number and string parameters, and can use
  the **default value defined in SAC** (2026.09). Multi actions (2026.19) support Member, Number,
  String, Date and Time, and have a **Validate** step that checks the setup against the backend.
- Set the planning area and the publish behaviour of the target version (do not publish /
  publish and fail on warnings / publish and ignore warnings) where the dialog offers them.
- Multi action runs can be followed in the SAC **Job Monitor**.

**Show and edit parameters on the sheet:**
```
B2   (the trigger cell)
B3   =SAP.GETPLANNINGTRIGGERNAME(B2)
B5   =SAP.GETPLANNINGTRIGGERPARAMETERS(B3,1,0)                 ' list of parameters
D5   =SAP.GETPLANNINGTRIGGERPARAMETERVALUE(B3,"SourceVersion",1,0)   ' with pencil → change on sheet
D6   =SAP.GETPLANNINGTRIGGERPARAMETERVALUE(B3,"TargetVersion",1,0)
```
This gives you a "run panel": the user checks the source and target values, then clicks the trigger.

**Parameters taken from story or table filters:** the filter must be on the same page as the
trigger, contain at most 100 members, and use no exclusions. Measure-input filters aren't
supported on measure-based models. If an old workbook fails on a date or time parameter, select
the parameter values again and save. A past fix changed how parameters on levelled hierarchies
are stored.

## 7. VBA for guided flows

Since Q2 2025 the add-in has a VBA API, shipped as the macro add-in `SAPOFXLA.xlam` with PDF
documentation (SAP Note 3594453). A common pattern:
- A button runs a macro that shows a **confirmation pop-up** with the parameter values (read from
  the trigger formulas above).
- The macro runs the data action and then refreshes.
- It shows a success or error message.

Keep the business logic in data actions. Use VBA only to guide the user. Save as `.xlsm`.

## 8. Planning checklist and error decoder

Before handing over a planning workbook:
- [ ] Every SETDATA names leaf members for its dimensions, and no combination is duplicated (key check).
- [ ] Each SETDATA block has a read-back GETDATA column.
- [ ] The version cell points at a version the users can write to. Private vs. public is decided.
- [ ] A test write of one value → Process → Refresh → Publish works end to end on a test version.
- [ ] *Optimize Data Retrieval* is on if there are more than a few hundred formula cells.
- [ ] Locked slices are documented, because the add-in won't show them.
- [ ] Trigger parameters are shown on the sheet, and the target version is visible before running.

| Symptom | Likely cause |
|---|---|
| Process Data stays greyed out | Planning not enabled on the table or data source; model not planning-enabled; value unchanged |
| SETDATA value ignored on first process | Mixed table and SETDATA input (KBA 3763022): process again |
| "Can't plan on node" / value not accepted | A named dimension points at a hierarchy node: use a leaf, or put the node in the filter |
| Published total ≠ entered total | Duplicate combinations (only one kept); unpinned dimension took a filter member you didn't expect |
| Publish refused | Data locks, or version is not in edit mode or not writeable |
| Other tables are grey | Normal: planning is one model at a time |
| Data action fails on date parameter | Select the levelled-hierarchy parameter again and save |
