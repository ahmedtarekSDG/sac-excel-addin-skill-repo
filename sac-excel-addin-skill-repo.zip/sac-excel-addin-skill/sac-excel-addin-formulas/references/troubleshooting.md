# Troubleshooting: symptoms, causes, known issues

## Quick decoder

| Symptom | Most likely causes (check in this order) |
|---|---|
| `#NAME?` | 1) Add-in not loaded or not signed in. 2) Formula written by a tool and not bound (`workbook-engineering.md` §1). 3) Unquoted dimension token read as a name. 4) A function that doesn't exist (`SAP.GETMEMBERS`, `SAP.GETMESSAGE`). 5) Wrong list separator for the locale (`,` vs `;`) |
| `=_xldudf_SAP_…` shown in the formula bar | That user's Excel doesn't recognise the add-in: disable/re-enable or reinstall the add-in |
| Blank or 0, no error | 1) **Description instead of ID** (member, version, entity). 2) An unpinned dimension took a filter member you didn't expect. 3) IFERROR caught the pending state. 4) Virtual "All members" or `""` used to mean all. 5) Period ID in the wrong format. 6) The source has no data there |
| Number changes when someone edits the table filter | Unpinned dimension falling back to the data source filter. Pin it |
| Old value after changing a filter | GETDATA isn't recalculated by filter changes: **Refresh → Refresh Sheet Functions** |
| `#VALUE!` | An argument is an error or blank (empty header row, empty anchor); invalid option code; text where a number is expected |
| `#REF!` | References a deleted sheet or cell (often summary sheets) |
| `#SPILL!` | A list function (TIMEOFFSET, GETDIMENSIONS, MEMBERPROPERTY, BLOCK, …) has no empty room to spill into |
| "Member/account is invalid" message | The member argument is blank or unknown (e.g. a subtotal row with no code) |
| TIMEOFFSET returns an error | Flat time dimension (it needs a hierarchy), BW or S/4HANA source, or the reference member is at the wrong level. Fall back to a native `EDATE` axis |
| OVERWRITEDIMENSIONFILTER "does nothing" | Table not refreshed afterwards; `Member_display` doesn't match how the members are written; several tables passed as `("T1","T2")` instead of `"T1, T2"` |
| Asymmetric filter returns no data | Used with YTD/QTD/MTD calculated measures (KBA 3639646); blocks with the wrong dimension IDs |
| GETDATACOMMENT blank | Commenting not enabled; the source isn't an SAC model; no comment on that exact combination |
| SETDATA not submitted | Planning not enabled; the version can't be written; **non-leaf** member named; value unchanged; mixed with table input on the first process (KBA 3763022) |
| Published total wrong | Duplicate SETDATA combinations; unpinned dimensions |
| Workbook slow or freezing | Volatile functions; thousands of formula cells with *Optimize Data Retrieval* off; many formulas pointing at the GETTABLENAME cell; formulas used where a table belongs |
| Works for me, not for a colleague | Data access control or model permissions; a different tenant; the add-in isn't loaded |
| Dev and Prod give different results | Dimension or member IDs differ between model copies. Re-check with `GETDIMENSIONS` / `inspect` |

## Debugging routine

1. **Build a test cell** next to the failing one: an **unwrapped** GETDATA with every dimension
   pinned to **literal IDs** copied from `SAP.GETDIMENSIONS(src,0,0,1)` and a helper table.
2. If the test cell works, swap the literals for the cell references **one at a time** until it
   breaks. The last one you swapped is the culprit.
3. If even literals fail, check the data source itself: `=SAP.GETTABLESTATUS(src,4)`, sign-in,
   tenant, permissions.
4. Check the number against a table or story with the same filters.

## Known issues and SAP notes worth knowing

| Note / KBA | Topic |
|---|---|
| 3783562 | Speed up GETDATA/SETDATA: *Workbook Preferences → Optimize Data Retrieval* |
| 3763022 | SETDATA values ignored on the first Process Data when mixed with table input |
| 3639646 | ASYMMETRICFILTER doesn't work with time-related calculated measures (YTD/QTD/MTD) |
| 3594453 | VBA API add-in (`SAPOFXLA.xlam`) and its documentation |
| 2770570 | Result-set size limits (the background to the tables' *high-volume mode*) |

## Habits that prevent most problems

- Read every dimension ID with `SAP.GETDIMENSIONS`. Never type one from memory.
- Use IDs everywhere and descriptions only in input cells, with a resolver to the ID.
- Pin every dimension the number depends on.
- Keep a visible connection-test cell on Control.
- Use no volatile functions and no IFERROR around data cells.
- Refresh sheet functions after changing filters.
