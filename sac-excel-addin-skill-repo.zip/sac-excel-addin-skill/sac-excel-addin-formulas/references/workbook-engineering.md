# Workbook engineering: generating, binding, inspecting and repairing add-in workbooks

Read this when **code** writes or edits the workbook (openpyxl, scripts, templates), when you
need IDs from a workbook the add-in saved, or when you're repairing an inherited file. These
rules are field-tested; the add-in's file format is not officially documented. Always finish
with the real test: open in Excel with the add-in signed in, then Refresh.

Tooling: `scripts/sac_xlsx_tools.py` (`inspect`, `profile-donor`, `bind`, `verify`).

## Contents
1. Why generated formulas open as `#NAME?`
2. The bound cell forms
3. Binding by cloning a donor
4. Zip surgery: never re-save a bound workbook with a library
5. Generating the workbook (before binding)
6. Reading the add-in's saved state (customXml)
7. Editing references safely: the three-step order
8. Converting static reports to dynamic ones
9. Repair playbook for inherited / half-built workbooks
10. IFERROR and asynchronous cells
11. Dropdowns across sheets
12. Verification checklist

---

## 1. Why generated formulas open as `#NAME?`

When Excel saves an add-in custom function, it doesn't store the dotted name you typed. It stores
an **underscore form plus dynamic-array metadata**:

```xml
<c r="D7" s="12" cm="1" vm="2"><f t="array" ref="D7">_xldudf_SAP_GETDATA("DS_1","Account",$A7,"Date",D$5)</f><v>0</v></c>
```

A library that writes `SAP.GETDATA(...)` as plain formula text produces a cell Excel can't link
to the add-in. It opens as `#NAME?`. Copying the sheet into a connected workbook doesn't fix it,
and retyping fixes only the cell you retype.

Related symptom on a user's PC: the formula bar shows `=_xldudf_SAP_GETDIMENSIONFILTER(...)` in
a file that works for everyone else. That machine's Excel didn't load the add-in. Disable and
re-enable the add-in, or reinstall it.

## 2. The bound cell forms

| Cell content | `<c>` attributes | `<f>` | `<v>` |
|---|---|---|---|
| Plain numeric call: `=SAP.GETDATA(…)` | `cm="<n>" vm="<m>"` (indices copied from the donor) | `t="array" ref="<cell>"` | `0` |
| Wrapped or combined numeric: `=IF(x="",0,SAP.GETDATA(…))`, `=GETDATA+GETDATA` | `cm="<n>"` (no `vm`) | `t="array" ref="<cell>"` | `0` |
| Text result: `GETTABLENAME`, `OVERWRITEDIMENSIONFILTER`, `GETDIMENSIONFILTER`, other text | `t="str" cm="<n>"` | `t="array" ref="<cell>"` | empty |

- `cm` is the 1-based index into `xl/metadata.xml` → `cellMetadata` (the dynamic-array entry, type `XLDAPR`).
- `vm` is the 1-based index into `valueMetadata` (the rich value entry, type `XLRICHVALUE`).
- **Use the indices the donor defines.** Read them from a donor cell of the same shape
  (`sac_xlsx_tools.py profile-donor` does this). Don't hardcode `cm="1" vm="2"` unless the donor
  uses those values.
- Set `<calcPr fullCalcOnLoad="1"/>` in `xl/workbook.xml` so Excel recalculates when the file opens.

## 3. Binding by cloning a donor

Writing `metadata.xml` and the rich-value parts by hand is fragile. Clone them from **one
workbook Excel bound itself** (the "donor"):

1. **Get a donor.** In any workbook connected to the tenant (the same tenant is safest), type one
   `=SAP.GETDATA(...)` with the add-in signed in. Optionally also type a `GETTABLENAME` and a
   wrapped `IF(…,SAP.GETDATA(…))` so every cell form is represented. Save.
2. **Copy these parts** from donor to target:
   ```
   xl/metadata.xml
   xl/richData/rdrichvalue.xml
   xl/richData/rdrichvaluestructure.xml
   xl/richData/richStyles.xml
   xl/richData/rdsupportingpropertybagstructure.xml
   xl/richData/rdsupportingpropertybag.xml
   xl/richData/rdRichValueTypes.xml
   ```
   (Copy whatever exists under `xl/richData/`; the exact set varies with the Excel build.)
3. **Register them:** add their `<Override>` entries to `[Content_Types].xml` (copied from the
   donor), and add their relationships to `xl/_rels/workbook.xml.rels`. Give the relationships
   **new `rId`s in an unused range** (e.g. `rId9001+`) so they can't collide.
4. **Convert every formula:** `SAP.X(` → `_xldudf_SAP_X(` with the right `cm`/`vm`/`t` for its
   form (§2).
5. **Set** `fullCalcOnLoad="1"`.
6. **Verify** (§12), then the user opens the file, signs in and refreshes.

One donor's metadata records are generic: hundreds of cells reuse the same `cm`/`vm` indices. On
refresh the add-in recalculates every value, so the cached values you write don't matter.

```bash
python scripts/sac_xlsx_tools.py profile-donor donor.xlsx
python scripts/sac_xlsx_tools.py bind generated.xlsx --donor donor.xlsx -o bound.xlsx --strip-iferror
python scripts/sac_xlsx_tools.py verify bound.xlsx --expect-bound
```

## 4. Zip surgery: never re-save a bound workbook with a library

openpyxl and most libraries **drop** the parts the add-in relies on: `customXml/*` (the add-in's
saved state), `xl/metadata.xml`, `xl/richData/*`, the web-extension / task-pane parts, and
sometimes data validations or defined names. Saving a bound or connected workbook with them
breaks it without any warning.

To change a bound workbook:
- Read the package as a zip.
- Edit only the XML strings you need (worksheet, sharedStrings, content types, rels).
- Write every other part back **byte for byte**, in the original order.
- Use openpyxl **read-only** for inspection only.
- Check the result with `zipfile.ZipFile(...).testzip()` and by re-opening it.

## 5. Generating the workbook (before binding)

- Build the layout with openpyxl as usual. Write formulas as **plain dotted text**
  (`=SAP.GETDATA(...)`). `#NAME?` at this stage is expected.
- Quote every dimension ID: `"PROFIT_CENTER"`, not `PROFIT_CENTER`. An unquoted token is read as
  a defined name and gives `#NAME?`.
- Watch for a missing leading underscore: `CONSOLIDATION_GROUP` vs `_CONSOLIDATION_GROUP`. Copy the
  IDs from `GETDIMENSIONS` or `inspect`.
- Concatenating formula fragments can produce a **double equals sign** (`==IF(…)+=IF(…)`). Build
  each formula as one string with a single leading `=`. `verify` flags `==` and `+=`.
- Store numeric-looking member IDs as text in Excel cells (`'00'`, `'001'`).
- Keep pick-lists in the same sheet as the dropdown, or use defined names (§11).
- Write formulas only, with no cached values, so the file doesn't carry stale numbers.

## 6. Reading the add-in's saved state (customXml)

A workbook the add-in has saved contains its state as a JSON document inside
`customXml/item*.xml`, usually in a CDATA block with a top-level `"document"` key. It holds:

| Path (typical) | Content |
|---|---|
| `document.dataSources.byId` | Model / view name, connection type, schema |
| `document.queries.byId.<Q>.availables[]` | Every dimension: `id`, `description`, `isMeasureDimension`, `isDateOrTimeDimension` |
| `document.queries.byId.<Q>.rows` / `.columns` | Dimensions on the axes |
| `document.queries.byId.<Q>.dimensionFilters` | Filtered members, often as unique names like `[DIM].[HIER].&[MEMBER]` |
| anywhere | Hierarchy names, measure member IDs |

```bash
python scripts/sac_xlsx_tools.py inspect connected.xlsx            # human-readable summary
python scripts/sac_xlsx_tools.py inspect connected.xlsx --json     # full extraction
```
Check the IDs you plan to use against this. IDs can differ between tenants, model versions and
Dev/QA/Prod copies of a model.

## 7. Editing references safely: the three-step order

When migrating many formulas (e.g. inserting rows on Control, moving literal IDs into Control
cells, adding a new dimension pair), do it in this order. Otherwise a reference you just wrote
gets shifted a second time:

1. **Shift** the existing Control references to their new row positions.
2. **Re-point** row-level literals to per-row cell references (e.g. the FS-item code → `$A9`).
3. **Insert** the new dimension-ID references or pairs (they already point at their final cells).

Run `verify` after each step and diff the formula counts.

## 8. Converting static reports to dynamic ones

Inherited reports often hardcode periods and entities.
- **Periods:** count the distinct period literals per sheet.
  - One distinct literal → replace it with the anchor (`Ctl!$B$5`).
  - Several (a month trend) → keep the month, make the year follow the anchor:
    current-year `"202509"` → `LEFT(Ctl!$B$5,4)&"09"`, prior year
    → `(VALUE(LEFT(Ctl!$B$5,4))-1)&"09"`.
- **Entities:** replace the literal with the Control's resolved-ID cell; the input stays a
  description dropdown.
- **Display names → IDs.** A display name (`"Head Office"`) instead of the member ID (`"1000"`)
  returns **0 or blank without any error**. Resolve through a lookup list.

## 9. Repair playbook for inherited / half-built workbooks

Check these **before** migrating. A migration doesn't fix them:

| Problem | Fix |
|---|---|
| `#REF!` from a deleted helper sheet (`Input!…`) | Re-point to the Control equivalent. For a lost numeric parameter use a neutral value and **flag it**. Never guess a number that drives results |
| Empty month-header row → `#VALUE!` in dependants | Refill it from the anchor (`=LEFT(anchor,4)&"01"` … `"12"`). Work out which columns from the formulas that read it; don't assume they're contiguous |
| Subtotal or header rows calling GETDATA on a blank code | Guard with `IF($A9="","",…)` or remove the formula |
| Bare dimension tokens | Quote them with the exact ID |
| `==` / `+=` inside formulas | Rebuild the formula string |
| Hardcoded entity / period | §8 |
| Summary sheets with `#REF!` but no SAP formulas | They reference deleted cells. A formula migration never touched them, so fix them separately |

## 10. IFERROR and asynchronous cells

GETDATA is asynchronous. Wrapping it, as in `=IFERROR(SAP.GETDATA(…),"")`, can catch the
temporary *pending* state, leave the cell **permanently blank**, and even make it text.
- Don't wrap bound data cells in IFERROR. Use `IF(guard, …)` for blank inputs instead.
- IFERROR is fine on the **alias cell** (`=IFERROR(SAP.GETTABLENAME(data!$A$1),"DS_1")`), on
  native lookups and resolvers, and on ratio cells (`=IFERROR(C9/D9,"-")`).
- When stripping a wrapper, match parentheses so the inner call stays intact, whatever the
  fallback is (`,0)`, `,"")`, `,"-")`). `bind --strip-iferror` does this.
- Keep one **unwrapped** test cell so real errors stay visible.

## 11. Dropdowns across sheets

A list validation written the classic way (`<dataValidation type="list"><formula1>$H$2:$H$25`)
reliably handles a **same-sheet range** or a **defined name**. Ranges on other sheets need the
newer `x14` extension form, which many libraries don't write.
- Keep pick-lists in unused columns of the same sheet (e.g. Control `J:M`), or
- define a name (`lst_Entity = _Lists!$A$2:$A$40`) and use `=lst_Entity` as the source.

## 12. Verification checklist

Check these with a script before shipping (`sac_xlsx_tools.py verify`):
- [ ] `testzip()` is clean and the file re-opens.
- [ ] No dotted `SAP.` left in `<f>` bodies (if bound); the `_xldudf_SAP_` count matches what you expect.
- [ ] `xl/metadata.xml` and `xl/richData/*` exist **and** are registered in content types and rels.
- [ ] No `IFERROR(…SAP.GETDATA` on data cells.
- [ ] No bare dimension tokens; no `==` or `+=`; no leftover placeholder IDs (`--forbid`).
- [ ] Every `cm`/`vm` index points at an entry that exists in `metadata.xml`.
- [ ] `fullCalcOnLoad="1"` is set.
- [ ] Spot-check one formula per sheet and per view (MTD/YTD).
- [ ] **Final test:** open in Excel with the add-in signed in → Refresh All → the reconciliation value matches.
