#!/usr/bin/env python3
"""
build_formula.py - build SAP Analytics Cloud add-in for Excel formulas (SAP.* functions)
with correct argument order, quoting, option codes and list separator.

Quoting rules (applied to every text argument):
  * Cell references stay unquoted. In ID positions a reference must be unambiguous - it needs a
    $, a sheet name, a range or a spill:  $A5  C$3  $B$1  Sheet1!B2  'My Sheet'!$B$3  A1:B9  A9#
    A bare token such as CC100, P100 or A1 is treated as a MEMBER ID. Force a plain relative
    reference with the ref: prefix:  ref:A5
  * "raw:" prefix forces a raw expression (defined names, nested formulas):  raw:MyName
    A leading "=" is treated the same way:  =SAP.TIMEOFFSET(...)
  * Already-quoted text is kept as is:  '"public.Actual"'
  * Everything else is quoted as text, with embedded quotes doubled.
  * Member / dimension IDs are ALWAYS text, even when numeric ("202501", "1000", "00").
  * Option codes (display, orientation, selection type, ...) are numbers or cell refs.
  * The SETDATA value is a number, a cell ref, or an expression (use raw: for expressions).

Examples
  build_formula.py GETDATA --table DS_1 --pairs Account=REVENUE Date=202501 Version=public.Actual
  build_formula.py GETDATA --table '$B$1' --pairs Account='$A5' Date='C$3'
  build_formula.py SETDATA --table DS_1 --value D5 --pairs Version=public.Plan Account=OPEX CostCenter=CC100 Date=202601
  build_formula.py GETDATACOMMENT --table Table1 --display 1 --pairs Account=REVENUE Date=202512
  build_formula.py GETDIMENSIONFILTER --table Table1 --dimension Product --member-display 3 --selection-display 1 --orientation 0
  build_formula.py OVERWRITEDIMENSIONFILTER --tables Table1 Table2 --dimension Region --members '$B$6' --selection-type 4 --member-display 0
  build_formula.py ASYMMETRICFILTER --tables Table1 --blocks 'K4#' 'K20#'
  build_formula.py BLOCK --pairs Version=public.Actual Date='H4#'
  build_formula.py TIMEOFFSET --table DS_1 --ref 202506 --offsets=-11..0 --display 0 --orientation 1
  build_formula.py GETTABLENAME --cell 'data!$A$1'
  build_formula.py GETTABLESTATUS --tables Table1 Table2 --display 4
  build_formula.py GETDIMENSIONS --table DS_1 --display 0 --orientation 0 --sort 1
  build_formula.py GETVARIABLES --table Table1 --variable City --variable-display 1 --value-display 1 --layout 3 --orientation 0
  build_formula.py MEMBERPROPERTY --table Table1 --dimension CostCenter --members A5:A60 --properties Description Currency --orientation 0
  build_formula.py GETPLANNINGTRIGGERNAME --cell B2
  build_formula.py GETPLANNINGTRIGGERPARAMETERS --trigger '$B$3' --display 1 --orientation 0
  build_formula.py GETPLANNINGTRIGGERPARAMETERVALUE --trigger '$B$3' --parameter TargetVersion --display 1 --orientation 0
  build_formula.py grid --table 'Ctl!$B$3' --rows A5:A20 --cols C3:N3 --row-dim Account --col-dim Date \
                        --fixed Version=public.Actual --guard
  build_formula.py grid --write --value-template 'Input!{col}{row}' --table DS_1 --rows A8:A20 \
                        --cols D7:O7 --row-dim Account --col-dim Date --fixed Version=public.Plan
  Negative offsets: write --offsets=-11..0 (with '=') so argparse does not read it as an option.
  Add --sep ';' for locales whose list separator is a semicolon.
"""

import argparse
import re
import sys

__version__ = "2.0.0"

_SHEET = r"(?:'(?:[^']|'')+'|[A-Za-z0-9_.À-￿]+)!"
_CELL = r"\$?[A-Za-z]{1,3}\$?\d+"
_COL = r"\$?[A-Za-z]{1,3}"
_ROW = r"\$?\d+"
_REF_RE = re.compile(
    rf"^(?:{_SHEET})?(?:{_CELL}(?::{_CELL})?#?|{_COL}:{_COL}|{_ROW}:{_ROW})$"
)
_NUM_RE = re.compile(r"^-?\d+(?:\.\d+)?$")
_INT_RE = re.compile(r"^-?\d+$")

FUNCTIONS = [
    "GETDATA", "SETDATA", "GETDATACOMMENT",
    "GETDIMENSIONFILTER", "OVERWRITEDIMENSIONFILTER", "ASYMMETRICFILTER", "BLOCK", "TIMEOFFSET",
    "GETTABLENAME", "GETTABLESTATUS", "GETDIMENSIONS", "GETVARIABLES", "MEMBERPROPERTY",
    "GETPLANNINGTRIGGERNAME", "GETPLANNINGTRIGGERPARAMETERS", "GETPLANNINGTRIGGERPARAMETERVALUE",
]


class BuildError(ValueError):
    pass


def is_ref(value):
    """Any Excel reference shape (used where an ID can't appear: values, option codes, blocks)."""
    return bool(_REF_RE.match(value.strip()))


def is_explicit_ref(value):
    """A reference in an ID position must be unambiguous: it needs $, a sheet, a range or a spill.
    'CC100', 'P100', 'A1' are treated as member IDs; write '$A5', 'C$3', 'Sheet!B2' or 'ref:A5'."""
    v = value.strip()
    return is_ref(v) and any(ch in v for ch in "$!:#")


def text(value):
    """Format a text argument (ID, name, dimension): ref/raw stays bare, else quoted."""
    if value is None:
        raise BuildError("missing value")
    v = str(value)
    if v.startswith("raw:"):
        return v[4:]
    if v.startswith("ref:"):
        if not is_ref(v[4:]):
            raise BuildError(f"{v!r} is not a cell reference")
        return v[4:].strip()
    if v.startswith("="):
        return v[1:]
    if len(v) >= 2 and v.startswith('"') and v.endswith('"'):
        return v
    if is_explicit_ref(v):
        return v.strip()
    return '"' + v.replace('"', '""') + '"'


def number_or_ref(value, name, allowed=None):
    """Format an option code: integer literal (checked against allowed) or a cell ref/raw."""
    v = str(value).strip()
    if v.startswith("raw:"):
        return v[4:]
    if v.startswith("="):
        return v[1:]
    if is_ref(v):
        return v
    if not _INT_RE.match(v):
        raise BuildError(f"{name} must be an integer code or a cell reference, got {value!r}")
    if allowed is not None and int(v) not in allowed:
        raise BuildError(f"{name}={v} is not valid; allowed: {sorted(allowed)}")
    return v


def value_arg(value):
    """SETDATA value: number or ref stays bare; raw:/= expression stays bare; else quoted."""
    v = str(value).strip()
    if v.startswith(("raw:", "ref:")):
        return v[4:]
    if v.startswith("="):
        return v[1:]
    if _NUM_RE.match(v) or is_ref(v):
        return v
    return text(v)


def tables_arg(tables):
    """One table/alias, several literal names joined in ONE string, or a single ref/range."""
    if not tables:
        raise BuildError("at least one table / data source is required")
    if len(tables) == 1:
        return text(tables[0])
    if any(is_explicit_ref(t) or t.startswith(("raw:", "ref:", "=")) for t in tables):
        raise BuildError("pass several tables either as literal names or as ONE range of cells, not a mix")
    return '"' + ", ".join(t.strip('"') for t in tables) + '"'


def parse_pairs(pairs, max_pairs=None):
    out = []
    for p in pairs or []:
        if "=" not in p:
            raise BuildError(f"pair {p!r} must be DIMENSION=MEMBER")
        dim, mem = p.split("=", 1)
        if not dim:
            raise BuildError(f"pair {p!r} has an empty dimension")
        out.append((dim, mem))
    if max_pairs is not None and len(out) > max_pairs:
        raise BuildError(f"at most {max_pairs} dimension/member pairs are allowed")
    return out


def pair_args(pairs):
    args = []
    for dim, mem in pairs:
        if mem == "":
            raise BuildError(f"dimension {dim!r} has an empty member; blank means 'unassigned', "
                             "omit the dimension instead to use the data source filter")
        args += [text(dim), text(mem)]
    return args


def expand_offsets(spec):
    """'-11..0' -> '-11,-10,...,0'; '-1,0,1' kept; a cell ref stays bare."""
    s = str(spec).strip()
    if is_explicit_ref(s) or s.startswith(("raw:", "ref:", "=")):
        return text(s)
    m = re.match(r"^(-?\d+)\s*\.\.\s*(-?\d+)$", s)
    if m:
        a, b = int(m.group(1)), int(m.group(2))
        step = 1 if b >= a else -1
        s = ",".join(str(i) for i in range(a, b + step, step))
    parts = [x.strip() for x in s.split(",") if x.strip()]
    if not parts or not all(_INT_RE.match(x) for x in parts):
        raise BuildError(f"offsets must be integers like '-11..0' or '-1,0,1', got {spec!r}")
    return '"' + ",".join(parts) + '"'


def optional_tail(spec):
    """spec: list of (formatted_value_or_None, default_or_None, name).
    Returns trailing args, filling earlier gaps with defaults; errors if a gap has no default."""
    last = max((i for i, (v, _, _) in enumerate(spec) if v is not None), default=-1)
    out = []
    for i in range(last + 1):
        v, default, name = spec[i]
        if v is None:
            if default is None:
                later = spec[last][2]
                raise BuildError(f"--{name} is required when --{later} is given")
            v = default
        out.append(v)
    return out


def opt(value, name, allowed):
    return None if value is None else number_or_ref(value, name, allowed)


def call(fn, args, sep):
    return f"=SAP.{fn}(" + sep.join(args) + ")"


# ----------------------------------------------------------------------------------------------
def build(a):
    fn = a.function
    sep = a.sep
    if fn == "GETDATA":
        pairs = parse_pairs(a.pairs)
        if not pairs:
            return call(fn, [text(a.table)], sep)
        return call(fn, [text(a.table)] + pair_args(pairs), sep)
    if fn == "SETDATA":
        pairs = parse_pairs(a.pairs)
        if not pairs:
            raise BuildError("SETDATA needs at least one DIMENSION=MEMBER pair")
        return call(fn, [text(a.table), value_arg(a.value)] + pair_args(pairs), sep)
    if fn == "GETDATACOMMENT":
        pairs = parse_pairs(a.pairs)
        return call(fn, [text(a.table), number_or_ref(a.display, "display", range(0, 5))] + pair_args(pairs), sep)
    if fn == "GETDIMENSIONFILTER":
        tail = optional_tail([
            (opt(a.member_display, "member-display", range(0, 7)), "2", "member-display"),
            (opt(a.selection_display, "selection-display", range(0, 5)), "4", "selection-display"),
            (opt(a.orientation, "orientation", (0, 1)), "0", "orientation"),
            (None if a.separator is None else text(a.separator), None, "separator"),
        ])
        return call(fn, [text(a.table), text(a.dimension)] + tail, sep)
    if fn == "OVERWRITEDIMENSIONFILTER":
        members = a.members
        if len(members) == 1:
            m = text(members[0])
        else:
            if any(is_explicit_ref(x) or x.startswith(("raw:", "ref:", "=")) for x in members):
                raise BuildError("several members: pass literal IDs, or ONE range / spill reference")
            m = '"' + ", ".join(members) + '"'
        tail = optional_tail([
            (opt(a.selection_type, "selection-type", range(0, 6)), "0", "selection-type"),
            (opt(a.member_display, "member-display", range(0, 5)), "0", "member-display"),
            (None if a.separator is None else text(a.separator), None, "separator"),
        ])
        return call(fn, [tables_arg(a.tables), text(a.dimension), m] + tail, sep)
    if fn == "ASYMMETRICFILTER":
        blocks = []
        for b in a.blocks:
            bb = b[4:] if b.startswith("raw:") else (b[1:] if b.startswith("=") else b)
            if not (is_ref(bb) or b.startswith(("raw:", "="))):
                raise BuildError(f"block {b!r} must be a range (F6:G9), a spill ref (A10#) or raw:/= expression")
            blocks.append(bb)
        return call(fn, [tables_arg(a.tables)] + blocks, sep)
    if fn == "BLOCK":
        pairs = parse_pairs(a.pairs, max_pairs=5)
        if not pairs:
            raise BuildError("BLOCK needs at least one DIMENSION=MEMBER pair")
        return call(fn, pair_args(pairs), sep)
    if fn == "TIMEOFFSET":
        tail = optional_tail([
            (opt(a.display, "display", range(0, 4)), "0", "display"),
            (opt(a.orientation, "orientation", (0, 1)), "1", "orientation"),
            (None if a.dimension is None else text(a.dimension), None, "dimension"),
        ])
        return call(fn, [text(a.table), text(a.ref), expand_offsets(a.offsets)] + tail, sep)
    if fn == "GETTABLENAME":
        if not is_ref(a.cell):
            raise BuildError("GETTABLENAME needs a cell reference")
        return call(fn, [a.cell.strip()], sep)
    if fn == "GETTABLESTATUS":
        args = [tables_arg(a.tables)]
        if a.display is not None:
            args.append(number_or_ref(a.display, "display", range(0, 5)))
        return call(fn, args, sep)
    if fn == "GETDIMENSIONS":
        tail = optional_tail([
            (opt(a.display, "display", range(0, 5)), "2", "display"),
            (opt(a.orientation, "orientation", (0, 1)), "0", "orientation"),
            (opt(a.sort, "sort", (0, 1, 2)), "0", "sort"),
        ])
        return call(fn, [text(a.table)] + tail, sep)
    if fn == "GETVARIABLES":
        tail = optional_tail([
            (opt(a.variable_display, "variable-display", (0, 1)), "1", "variable-display"),
            (opt(a.value_display, "value-display", (0, 1)), "0", "value-display"),
            (opt(a.layout, "layout", None), None, "layout"),
            (opt(a.orientation, "orientation", (0, 1)), "1", "orientation"),
        ])
        return call(fn, [text(a.table), text(a.variable)] + tail, sep)
    if fn == "MEMBERPROPERTY":
        members = a.members
        if len(members) == 1:
            m = text(members[0])
        else:
            if any(is_explicit_ref(x) or x.startswith(("raw:", "ref:", "=")) for x in members):
                raise BuildError("several members: pass literal IDs, or ONE range")
            m = '"' + ", ".join(members) + '"'
        props = a.properties
        p = text(props[0]) if len(props) == 1 else '"' + ", ".join(props) + '"'
        args = [text(a.table), text(a.dimension), m, p]
        if a.orientation is not None:
            args.append(number_or_ref(a.orientation, "orientation", (0, 1)))
        return call(fn, args, sep)
    if fn == "GETPLANNINGTRIGGERNAME":
        if not is_ref(a.cell):
            raise BuildError("GETPLANNINGTRIGGERNAME needs a cell reference")
        return call(fn, [a.cell.strip()], sep)
    if fn == "GETPLANNINGTRIGGERPARAMETERS":
        tail = optional_tail([
            (opt(a.display, "display", range(0, 4)), None, "display"),
            (opt(a.orientation, "orientation", (0, 1)), None, "orientation"),
        ])
        return call(fn, [text(a.trigger)] + tail, sep)
    if fn == "GETPLANNINGTRIGGERPARAMETERVALUE":
        tail = optional_tail([
            (opt(a.display, "display", range(0, 4)), "2", "display"),
            (opt(a.orientation, "orientation", (0, 1)), None, "orientation"),
        ])
        return call(fn, [text(a.trigger), text(a.parameter)] + tail, sep)
    raise BuildError(f"unknown function {fn}")


# ----------------------------------------------------------------------------------------------
_RANGE_RE = re.compile(r"^(?:(" + _SHEET + r"))?\$?([A-Za-z]{1,3})\$?(\d+)(?::\$?([A-Za-z]{1,3})\$?(\d+))?$")


def col_to_num(col):
    n = 0
    for ch in col.upper():
        n = n * 26 + (ord(ch) - 64)
    return n


def num_to_col(n):
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def parse_range(rng):
    m = _RANGE_RE.match(rng.strip())
    if not m:
        raise BuildError(f"not a range: {rng!r}")
    sheet, c1, r1, c2, r2 = m.groups()
    c2 = c2 or c1
    r2 = r2 or r1
    return sheet or "", col_to_num(c1), int(r1), col_to_num(c2), int(r2)


def build_grid(a):
    """Formula block: one formula per (row ID cell) x (column ID cell)."""
    rs, rc1, rr1, rc2, rr2 = parse_range(a.rows)
    cs, cc1, cr1, cc2, cr2 = parse_range(a.cols)
    if rc1 != rc2:
        raise BuildError("--rows must be a single column, e.g. A5:A20")
    if cr1 != cr2:
        raise BuildError("--cols must be a single row, e.g. C3:N3")
    row_col = num_to_col(rc1)
    fixed = pair_args(parse_pairs(a.fixed))
    out = []
    for r in range(rr1, rr2 + 1):
        line = []
        for c in range(cc1, cc2 + 1):
            col = num_to_col(c)
            row_ref = f"{rs}${row_col}{r}"
            col_ref = f"{cs}{col}${cr1}"
            pairs = [text(a.row_dim), row_ref, text(a.col_dim), col_ref] + fixed
            if a.write:
                if not a.value_template:
                    raise BuildError("grid SETDATA needs --value-template, e.g. 'Input!{col}{row}'")
                val = a.value_template.format(col=col, row=r)
                body = f"SAP.SETDATA({a.sep.join([text(a.table), val] + pairs)})"
            else:
                body = f"SAP.GETDATA({a.sep.join([text(a.table)] + pairs)})"
            if a.guard:
                body = f'IF({row_ref}=""{a.sep}""{a.sep}{body})'
            line.append((f"{col}{r}", "=" + body))
        out.append(line)
    return out


def main(argv=None):
    p = argparse.ArgumentParser(
        prog="build_formula.py",
        description="Build SAP Analytics Cloud add-in for Excel formulas (SAP.*).",
        formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    p.add_argument("--version", action="version", version=__version__)
    sub = p.add_subparsers(dest="function", required=True, metavar="FUNCTION")

    def add(name, help_):
        sp = sub.add_parser(name, help=help_)
        sp.add_argument("--sep", default=",", choices=[",", ";"], help="list separator (default ,)")
        return sp

    sp = add("GETDATA", "read a value")
    sp.add_argument("--table", required=True); sp.add_argument("--pairs", nargs="*", default=[])
    sp = add("SETDATA", "write a value (planning)")
    sp.add_argument("--table", required=True); sp.add_argument("--value", required=True)
    sp.add_argument("--pairs", nargs="+", required=True)
    sp = add("GETDATACOMMENT", "last data point comment (+ value)")
    sp.add_argument("--table", required=True); sp.add_argument("--display", default="0")
    sp.add_argument("--pairs", nargs="*", default=[])
    sp = add("GETDIMENSIONFILTER", "show filter + filter button")
    sp.add_argument("--table", required=True); sp.add_argument("--dimension", required=True)
    sp.add_argument("--member-display"); sp.add_argument("--selection-display")
    sp.add_argument("--orientation"); sp.add_argument("--separator")
    sp = add("OVERWRITEDIMENSIONFILTER", "set a filter on one or more tables / data sources")
    sp.add_argument("--tables", nargs="+", required=True); sp.add_argument("--dimension", required=True)
    sp.add_argument("--members", nargs="+", required=True)
    sp.add_argument("--selection-type"); sp.add_argument("--member-display"); sp.add_argument("--separator")
    sp = add("ASYMMETRICFILTER", "apply asymmetric filter blocks")
    sp.add_argument("--tables", nargs="+", required=True); sp.add_argument("--blocks", nargs="+", required=True)
    sp = add("BLOCK", "build a block (up to 5 pairs)")
    sp.add_argument("--pairs", nargs="+", required=True)
    sp = add("TIMEOFFSET", "relative time members (spills)")
    sp.add_argument("--table", required=True); sp.add_argument("--ref", required=True)
    sp.add_argument("--offsets", required=True, help="'-11..0', '-1,0,1' or a cell ref")
    sp.add_argument("--display"); sp.add_argument("--orientation"); sp.add_argument("--dimension")
    sp = add("GETTABLENAME", "table name of a cell")
    sp.add_argument("--cell", required=True)
    sp = add("GETTABLESTATUS", "refresh status of tables")
    sp.add_argument("--tables", nargs="+", required=True); sp.add_argument("--display")
    sp = add("GETDIMENSIONS", "list dimensions")
    sp.add_argument("--table", required=True); sp.add_argument("--display")
    sp.add_argument("--orientation"); sp.add_argument("--sort")
    sp = add("GETVARIABLES", "variable (prompt) values")
    sp.add_argument("--table", required=True); sp.add_argument("--variable", required=True)
    sp.add_argument("--variable-display"); sp.add_argument("--value-display")
    sp.add_argument("--layout"); sp.add_argument("--orientation")
    sp = add("MEMBERPROPERTY", "member attribute values")
    sp.add_argument("--table", required=True); sp.add_argument("--dimension", required=True)
    sp.add_argument("--members", nargs="+", required=True)
    sp.add_argument("--properties", nargs="+", required=True); sp.add_argument("--orientation")
    sp = add("GETPLANNINGTRIGGERNAME", "planning trigger name of a cell")
    sp.add_argument("--cell", required=True)
    sp = add("GETPLANNINGTRIGGERPARAMETERS", "list trigger parameters")
    sp.add_argument("--trigger", required=True); sp.add_argument("--display"); sp.add_argument("--orientation")
    sp = add("GETPLANNINGTRIGGERPARAMETERVALUE", "trigger parameter value + edit icon")
    sp.add_argument("--trigger", required=True); sp.add_argument("--parameter", required=True)
    sp.add_argument("--display"); sp.add_argument("--orientation")

    sp = add("grid", "emit a block of GETDATA/SETDATA formulas")
    sp.add_argument("--write", action="store_true", help="emit SETDATA instead of GETDATA (needs --value-template)")
    sp.add_argument("--table", required=True)
    sp.add_argument("--rows", required=True, help="single-column range of row member IDs, e.g. A5:A20")
    sp.add_argument("--cols", required=True, help="single-row range of column member IDs, e.g. C3:N3")
    sp.add_argument("--row-dim", required=True); sp.add_argument("--col-dim", required=True)
    sp.add_argument("--fixed", nargs="*", default=[], help="pinned DIMENSION=MEMBER pairs")
    sp.add_argument("--value-template", help="SETDATA value per cell, e.g. 'Input!{col}{row}'")
    sp.add_argument("--guard", action="store_true", help='wrap in IF(<row id>="","",...)')
    sp.add_argument("--format", default="cells", choices=["cells", "matrix"],
                    help="cells: 'C5<TAB>=formula' lines; matrix: tab-separated rows to paste")

    a = p.parse_args(argv)
    try:
        if a.function == "grid":
            grid = build_grid(a)
            if a.format == "matrix":
                for line in grid:
                    print("\t".join(f for _, f in line))
            else:
                for line in grid:
                    for addr, f in line:
                        print(f"{addr}\t{f}")
        else:
            print(build(a))
    except BuildError as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
