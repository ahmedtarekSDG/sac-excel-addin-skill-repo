#!/usr/bin/env python3
"""
sac_xlsx_tools.py - inspect, bind and verify SAP Analytics Cloud add-in workbooks (.xlsx/.xlsm)
without re-saving them through a spreadsheet library (which would drop the add-in's parts).

Commands
  inspect        Read the add-in's saved state (customXml JSON): data sources, dimension IDs,
                 axes, filters, member unique names. Count SAP formulas per sheet.
  profile-donor  Show a donor workbook's binding parts and the cm/vm/t attributes its SAP cells use.
  bind           Make generated "=SAP.*(...)" formulas bind: clone xl/metadata.xml + xl/richData/*
                 from a donor that Excel bound itself, register the parts, convert every formula to
                 the "_xldudf_SAP_*" dynamic-array form, set fullCalcOnLoad. Optional IFERROR strip.
  verify         Pre-ship checklist; exits 1 when a check fails.

Examples
  python sac_xlsx_tools.py inspect connected.xlsx
  python sac_xlsx_tools.py inspect connected.xlsx --json > state.json
  python sac_xlsx_tools.py inspect report.xlsx --formulas --limit 50
  python sac_xlsx_tools.py profile-donor donor.xlsx
  python sac_xlsx_tools.py bind generated.xlsx --donor donor.xlsx -o bound.xlsx --strip-iferror
  python sac_xlsx_tools.py verify bound.xlsx --expect-bound --forbid "PLACEHOLDER_" --forbid "TODO"

Standard library only. The workbook file format used by the add-in is not officially documented;
these rules are field-tested. Final proof is always: open in Excel, sign in, Refresh All.
"""

import argparse
import collections
import json
import re
import sys
import zipfile
from xml.sax.saxutils import escape as _xml_escape

__version__ = "2.0.0"

KNOWN_FUNCS = {
    "GETDATA", "SETDATA", "GETDATACOMMENT",
    "GETDIMENSIONFILTER", "OVERWRITEDIMENSIONFILTER", "ASYMMETRICFILTER", "BLOCK", "TIMEOFFSET",
    "GETTABLENAME", "GETTABLESTATUS", "GETDIMENSIONS", "GETVARIABLES", "MEMBERPROPERTY",
    "GETPLANNINGTRIGGERNAME", "GETPLANNINGTRIGGERPARAMETERS", "GETPLANNINGTRIGGERPARAMETERVALUE",
}
NUMERIC_FUNCS = {"GETDATA", "SETDATA"}
PAIR_FUNCS = {"GETDATA": 1, "SETDATA": 2, "GETDATACOMMENT": 2}   # index of first dimension arg

CALL_RE = re.compile(r"(?<![A-Za-z0-9_.])(SAP\.|_xldudf_SAP_)([A-Za-z]+)\(")
CELL_RE = re.compile(r"<c\b([^>]*?)(?:/>|>(.*?)</c>)", re.S)
F_RE = re.compile(r"<f\b([^>]*?)(?:/>|>(.*?)</f>)", re.S)
ATTR_RE = re.compile(r'([A-Za-z_:][-A-Za-z0-9_:.]*)="([^"]*)"')
REF_TOKEN_RE = re.compile(
    r"^(?:(?:'(?:[^']|'')+'|[A-Za-z0-9_.]+)!)?(?:\$?[A-Za-z]{1,3}\$?\d+(?::\$?[A-Za-z]{1,3}\$?\d+)?#?"
    r"|\$?[A-Za-z]{1,3}:\$?[A-Za-z]{1,3}|\$?\d+:\$?\d+)$")
IDENT_RE = re.compile(r"^_?[A-Za-z][A-Za-z0-9_.]*$")


# ------------------------------------------------------------------------------- xml helpers
def xml_unescape(s):
    return (s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", '"')
             .replace("&apos;", "'").replace("&amp;", "&"))


def xml_escape(s):
    return _xml_escape(s)


def parse_attrs(attr_str):
    return collections.OrderedDict(ATTR_RE.findall(attr_str or ""))


def build_attrs(attrs):
    return "".join(f' {k}="{v}"' for k, v in attrs.items())


# ------------------------------------------------------------------------------- package
class Package:
    def __init__(self, path):
        self.path = path
        with zipfile.ZipFile(path) as zf:
            self.order = [i.filename for i in zf.infolist()]
            self.parts = {n: zf.read(n) for n in self.order}

    def text(self, name):
        return self.parts[name].decode("utf-8")

    def has(self, name):
        return name in self.parts

    def set_text(self, name, value):
        if name not in self.parts:
            self.order.append(name)
        self.parts[name] = value.encode("utf-8")

    def set_bytes(self, name, value):
        if name not in self.parts:
            self.order.append(name)
        self.parts[name] = value

    def save(self, path):
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
            for n in self.order:
                zf.writestr(n, self.parts[n])

    def sheets(self):
        """[(sheet name, part name)] in workbook order."""
        wb = self.text("xl/workbook.xml")
        rels = self.text("xl/_rels/workbook.xml.rels") if self.has("xl/_rels/workbook.xml.rels") else ""
        rid_target = {}
        for m in re.finditer(r"<Relationship\b([^>]*)/?>", rels):
            a = parse_attrs(m.group(1))
            rid_target[a.get("Id")] = a.get("Target", "")
        out = []
        for m in re.finditer(r"<sheet\b([^>]*)/?>", wb):
            a = parse_attrs(m.group(1))
            rid = a.get("r:id") or next((v for k, v in a.items() if k.endswith(":id")), None)
            tgt = rid_target.get(rid, "")
            part = tgt.lstrip("/") if tgt.startswith("/") else "xl/" + tgt
            if part in self.parts:
                out.append((xml_unescape(a.get("name", part)), part))
        if not out:  # fallback
            out = [(n.split("/")[-1], n) for n in self.order if re.match(r"xl/worksheets/sheet\d+\.xml$", n)]
        return out

    def defined_names(self):
        wb = self.text("xl/workbook.xml")
        return {xml_unescape(m.group(1)) for m in re.finditer(r'<definedName\b[^>]*\bname="([^"]+)"', wb)}


# ------------------------------------------------------------------------------- formula parsing
def string_mask(formula):
    """Boolean list: True where the char is inside a "..." string literal."""
    mask = [False] * len(formula)
    i, inside = 0, False
    while i < len(formula):
        ch = formula[i]
        if ch == '"':
            if inside and i + 1 < len(formula) and formula[i + 1] == '"':
                mask[i] = mask[i + 1] = True
                i += 2
                continue
            mask[i] = True
            inside = not inside
        else:
            mask[i] = inside
        i += 1
    return mask


def matching_paren(formula, open_idx, mask=None):
    mask = mask or string_mask(formula)
    depth = 0
    for i in range(open_idx, len(formula)):
        if mask[i]:
            continue
        if formula[i] in "({[":
            depth += 1
        elif formula[i] in ")}]":
            depth -= 1
            if depth == 0:
                return i
    return -1


def split_args(argstr):
    mask = string_mask(argstr)
    out, depth, start = [], 0, 0
    for i, ch in enumerate(argstr):
        if mask[i]:
            continue
        if ch in "({[":
            depth += 1
        elif ch in ")}]":
            depth -= 1
        elif ch == "," and depth == 0:
            out.append(argstr[start:i].strip())
            start = i + 1
    out.append(argstr[start:].strip())
    return out if (len(out) > 1 or out[0]) else []


def find_calls(formula):
    """[(prefix, fn, args_list, start, end_inclusive)] for SAP calls outside string literals."""
    mask = string_mask(formula)
    calls = []
    for m in CALL_RE.finditer(formula):
        if mask[m.start()]:
            continue
        open_idx = m.end() - 1
        close = matching_paren(formula, open_idx, mask)
        if close < 0:
            calls.append((m.group(1), m.group(2).upper(), None, m.start(), len(formula) - 1))
            continue
        calls.append((m.group(1), m.group(2).upper(), split_args(formula[open_idx + 1:close]), m.start(), close))
    return calls


def single_call(body):
    """If the whole formula body is one SAP call, return its function name."""
    b = body.strip()
    m = CALL_RE.match(b)
    if not m or m.start() != 0:
        return None
    close = matching_paren(b, m.end() - 1)
    return m.group(2).upper() if close == len(b) - 1 else None


def strip_iferror(body):
    """Remove IFERROR(x, fallback) wrappers whose first argument contains a data call."""
    changed = True
    while changed:
        changed = False
        mask = string_mask(body)
        for m in re.finditer(r"(?<![A-Za-z0-9_.])IFERROR\(", body, re.I):
            if mask[m.start()]:
                continue
            close = matching_paren(body, m.end() - 1, mask)
            if close < 0:
                continue
            args = split_args(body[m.end():close])
            if args and re.search(r"(SAP\.|_xldudf_SAP_)(GETDATA|SETDATA)\(", args[0], re.I):
                body = body[:m.start()] + args[0] + body[close + 1:]
                changed = True
                break
    return body


def iter_formula_cells(xml):
    """Yield (match, cell_attrs, inner, f_attrs, formula_text_unescaped) for cells with <f>text</f>."""
    for cm in CELL_RE.finditer(xml):
        inner = cm.group(2) or ""
        fm = F_RE.search(inner)
        if not fm:
            continue
        ftext = fm.group(2)
        yield cm, parse_attrs(cm.group(1)), inner, parse_attrs(fm.group(1)), (xml_unescape(ftext) if ftext else None)


# ------------------------------------------------------------------------------- metadata.xml
def metadata_info(xml):
    """Return dict with metadataTypes, cellMetadata/valueMetadata bk lists and XLDAPR/XLRICHVALUE indices."""
    types = [parse_attrs(m.group(1)).get("name") for m in re.finditer(r"<metadataType\b([^>]*)/?>", xml)]

    def blocks(tag):
        m = re.search(rf"<{tag}\b[^>]*>(.*?)</{tag}>", xml, re.S)
        if not m:
            return []
        out = []
        for bk in re.finditer(r"<bk>(.*?)</bk>", m.group(1), re.S):
            rcs = [parse_attrs(r.group(1)) for r in re.finditer(r"<rc\b([^>]*)/?>", bk.group(1))]
            out.append(rcs)
        return out

    cell_bk, value_bk = blocks("cellMetadata"), blocks("valueMetadata")

    def index_for(bks, type_name):
        for i, rcs in enumerate(bks, 1):
            for rc in rcs:
                t = int(rc.get("t", "0"))
                if 1 <= t <= len(types) and types[t - 1] == type_name:
                    return i
        return None

    return {"types": types, "cell_count": len(cell_bk), "value_count": len(value_bk),
            "xldapr_cm": index_for(cell_bk, "XLDAPR"), "richvalue_vm": index_for(value_bk, "XLRICHVALUE")}


# ------------------------------------------------------------------------------- customXml state
def extract_state_docs(pkg):
    docs = []
    for name in pkg.order:
        if not re.match(r"customXml/item\d+\.xml$", name):
            continue
        raw = pkg.parts[name].decode("utf-8", "replace")
        candidates = re.findall(r"<!\[CDATA\[(.*?)\]\]>", raw, re.S)
        if not candidates:
            body = re.sub(r"<\?xml[^>]*\?>", "", raw).strip()
            body = re.sub(r"^<[^>]+>|<[^>]+>$", "", body).strip()
            candidates = [xml_unescape(body)]
        for c in candidates:
            c = c.strip()
            if not c.startswith(("{", "[")):
                continue
            try:
                docs.append((name, json.loads(c)))
            except ValueError:
                continue
    return docs


def walk(obj, path=""):
    yield path, obj
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield from walk(v, f"{path}.{k}" if path else k)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            yield from walk(v, f"{path}[{i}]")


def summarize_state(doc):
    root = doc.get("document", doc) if isinstance(doc, dict) else doc
    out = {"dataSources": [], "queries": [], "memberUniqueNames": []}
    if isinstance(root, dict):
        ds = (root.get("dataSources") or {}).get("byId") or {}
        for dsid, d in ds.items():
            if isinstance(d, dict):
                out["dataSources"].append({"id": dsid, **{k: v for k, v in d.items()
                                                          if isinstance(v, (str, int, float, bool)) and len(str(v)) <= 160}})
    for path, node in walk(root):
        if isinstance(node, dict) and isinstance(node.get("availables"), list):
            q = {"path": path, "dataSourceId": node.get("dataSourceId"),
                 "rows": node.get("rows"), "columns": node.get("columns"), "dimensions": []}
            for a in node["availables"]:
                if isinstance(a, dict) and "id" in a:
                    q["dimensions"].append({"id": a.get("id"), "description": a.get("description"),
                                            "isMeasure": a.get("isMeasureDimension"),
                                            "isDate": a.get("isDateOrTimeDimension")})
            if "dimensionFilters" in node:
                q["dimensionFilters"] = node.get("dimensionFilters")
            out["queries"].append(q)
    text = json.dumps(root)
    seen = set()
    for m in re.finditer(r"\[([^\[\]\"]+)\]\.\[([^\[\]\"]+)\]\.&\[([^\[\]\"]+)\]", text):
        if m.groups() not in seen:
            seen.add(m.groups())
            out["memberUniqueNames"].append({"dimension": m.group(1), "hierarchy": m.group(2), "member": m.group(3)})
    return out


# ------------------------------------------------------------------------------- commands
def formula_stats(pkg):
    stats = collections.OrderedDict()
    for sname, part in pkg.sheets():
        s = collections.Counter()
        for _, cattrs, _, fattrs, ftext in iter_formula_cells(pkg.text(part)):
            if not ftext:
                continue
            for prefix, fn, _, _, _ in find_calls(ftext):
                s[("dotted" if prefix == "SAP." else "bound", fn)] += 1
        stats[sname] = s
    return stats


def cmd_inspect(a):
    pkg = Package(a.file)
    docs = extract_state_docs(pkg)
    summaries = [{"part": n, **summarize_state(d)} for n, d in docs]
    stats = formula_stats(pkg)
    if a.json:
        out = {"file": a.file, "state": summaries,
               "formulas": {s: {f"{k[0]}:{k[1]}": v for k, v in c.items()} for s, c in stats.items()}}
        if a.raw:
            out["raw"] = {n: d for n, d in docs}
        print(json.dumps(out, indent=2, default=str))
        return 0
    n_rich = sum(1 for n in pkg.order if n.startswith("xl/richData/"))
    n_cx = sum(1 for n in pkg.order if re.match(r"customXml/item\d+\.xml$", n))
    print(f"== {a.file}")
    print(f"parts: {len(pkg.order)} | metadata.xml: {pkg.has('xl/metadata.xml')} | "
          f"richData parts: {n_rich} | customXml items: {n_cx}")
    if not summaries:
        print("\nNo add-in state found in customXml (file not saved by the add-in, or a different format).")
    for s in summaries:
        print(f"\n-- add-in state in {s['part']}")
        for d in s["dataSources"]:
            print("  data source:", ", ".join(f"{k}={v}" for k, v in d.items()))
        for q in s["queries"]:
            print(f"  query {q['path']}  dataSourceId={q['dataSourceId']}")
            print(f"    rows={q['rows']}  columns={q['columns']}")
            for d in q["dimensions"]:
                flag = " [measure]" if d["isMeasure"] else (" [time]" if d["isDate"] else "")
                print(f"    {str(d['id']):40s} {str(d['description'] or ''):40s}{flag}")
            if q.get("dimensionFilters"):
                txt = json.dumps(q["dimensionFilters"])
                print(f"    dimensionFilters: {txt[:600]}{' …' if len(txt) > 600 else ''}")
        if s["memberUniqueNames"]:
            print("  member unique names seen:")
            for u in s["memberUniqueNames"][:a.limit]:
                print(f"    [{u['dimension']}].[{u['hierarchy']}].&[{u['member']}]")
    print("\n-- SAP formulas per sheet (dotted = written as text / not bound, bound = _xldudf_ form)")
    for sname, c in stats.items():
        if c:
            print(f"  {sname}: " + ", ".join(f"{k[1]}[{k[0]}]={v}" for k, v in sorted(c.items())))
    if a.formulas:
        print("\n-- formula cells")
        n = 0
        for sname, part in pkg.sheets():
            for cm, cattrs, _, fattrs, ftext in iter_formula_cells(pkg.text(part)):
                if ftext and CALL_RE.search(ftext):
                    print(f"  {sname}!{cattrs.get('r')}  [t={cattrs.get('t','')} cm={cattrs.get('cm','')} "
                          f"vm={cattrs.get('vm','')}]  ={ftext}")
                    n += 1
                    if n >= a.limit:
                        print("  … (use --limit)")
                        return 0
    return 0


def donor_profile(pkg):
    prof = {"parts": [n for n in pkg.order if n == "xl/metadata.xml" or n.startswith("xl/richData/")],
            "by_function": {}, "by_shape": {}, "metadata": None}
    if pkg.has("xl/metadata.xml"):
        prof["metadata"] = metadata_info(pkg.text("xl/metadata.xml"))
    fn_counter = collections.defaultdict(collections.Counter)
    shape_counter = collections.defaultdict(collections.Counter)
    for sname, part in pkg.sheets():
        for _, cattrs, _, fattrs, ftext in iter_formula_cells(pkg.text(part)):
            if not ftext or "_xldudf_SAP_" not in ftext:
                continue
            key = (cattrs.get("t"), cattrs.get("cm"), cattrs.get("vm"))
            fn = single_call(ftext)
            if fn:
                fn_counter[fn][key] += 1
                shape = "text" if cattrs.get("t") == "str" else ("plain" if fn in NUMERIC_FUNCS else "other")
            else:
                shape = "text" if cattrs.get("t") == "str" else "wrapped"
            shape_counter[shape][key] += 1
    for fn, c in fn_counter.items():
        prof["by_function"][fn] = dict(zip(("t", "cm", "vm"), c.most_common(1)[0][0]))
    for sh, c in shape_counter.items():
        prof["by_shape"][sh] = dict(zip(("t", "cm", "vm"), c.most_common(1)[0][0]))
    return prof


def cmd_profile(a):
    prof = donor_profile(Package(a.donor))
    print(json.dumps(prof, indent=2))
    ok = bool(prof["metadata"]) and any(p.startswith("xl/richData/") for p in prof["parts"])
    if not ok:
        print("\nWARNING: donor lacks xl/metadata.xml or xl/richData/* - it was not bound by Excel.", file=sys.stderr)
    return 0 if ok else 1


def _rels_add(target_rels, donor_rels, copied_parts):
    """Copy donor workbook relationships that point at copied parts, with fresh rIds."""
    existing_targets = {parse_attrs(m.group(1)).get("Target", "").lstrip("/").replace("xl/", "", 1)
                        for m in re.finditer(r"<Relationship\b([^>]*)/?>", target_rels)}
    used = {parse_attrs(m.group(1)).get("Id") for m in re.finditer(r"<Relationship\b([^>]*)/?>", target_rels)}
    nxt = 9001
    added = []
    for m in re.finditer(r"<Relationship\b([^>]*)/?>", donor_rels):
        at = parse_attrs(m.group(1))
        tgt = at.get("Target", "")
        norm = tgt.lstrip("/")
        norm = norm[3:] if norm.startswith("xl/") else norm
        if "xl/" + norm not in copied_parts or norm in existing_targets:
            continue
        while f"rId{nxt}" in used:
            nxt += 1
        at["Id"] = f"rId{nxt}"
        used.add(at["Id"])
        added.append(f"<Relationship{build_attrs(at)}/>")
    if added:
        target_rels = target_rels.replace("</Relationships>", "".join(added) + "</Relationships>")
    return target_rels, len(added)


def _ct_add(target_ct, donor_ct, copied_parts):
    have = {parse_attrs(m.group(1)).get("PartName") for m in re.finditer(r"<Override\b([^>]*)/?>", target_ct)}
    added = []
    for m in re.finditer(r"<Override\b([^>]*)/?>", donor_ct):
        at = parse_attrs(m.group(1))
        pn = at.get("PartName", "")
        if pn.lstrip("/") in copied_parts and pn not in have:
            added.append(f"<Override{build_attrs(at)}/>")
    # rels of richData parts (if any) need the rels default, normally present already
    if added:
        target_ct = target_ct.replace("</Types>", "".join(added) + "</Types>")
    return target_ct, len(added)


def _set_full_calc(wb_xml):
    if re.search(r"<calcPr\b", wb_xml):
        def fix(m):
            at = parse_attrs(m.group(1))
            at["fullCalcOnLoad"] = "1"
            return f"<calcPr{build_attrs(at)}/>"
        return re.sub(r"<calcPr\b([^>]*?)/>", fix, wb_xml, count=1)
    anchor = "</definedNames>" if "</definedNames>" in wb_xml else "</sheets>"
    return wb_xml.replace(anchor, anchor + '<calcPr fullCalcOnLoad="1"/>', 1)


def cmd_bind(a):
    tgt, donor = Package(a.file), Package(a.donor)
    prof = donor_profile(donor)
    meta = prof["metadata"]
    if not meta or not any(p.startswith("xl/richData/") for p in prof["parts"]):
        print("error: donor has no xl/metadata.xml + xl/richData/*; type one =SAP.GETDATA(...) in a "
              "connected workbook with the add-in signed in, save, and use that file.", file=sys.stderr)
        return 2
    warnings = []

    # 1) parts
    if tgt.has("xl/metadata.xml") and not a.replace_metadata:
        print("error: target already has xl/metadata.xml; pass --replace-metadata to overwrite it "
              "with the donor's binding parts.", file=sys.stderr)
        return 2
    copied = []
    for p in prof["parts"]:
        tgt.set_bytes(p, donor.parts[p])
        copied.append(p)
    for p in donor.order:  # rels belonging to richData parts, if the donor has them
        if p.startswith("xl/richData/_rels/"):
            tgt.set_bytes(p, donor.parts[p])
            copied.append(p)
    ct, n_ct = _ct_add(tgt.text("[Content_Types].xml"), donor.text("[Content_Types].xml"), set(copied))
    tgt.set_text("[Content_Types].xml", ct)
    rels, n_rel = _rels_add(tgt.text("xl/_rels/workbook.xml.rels"), donor.text("xl/_rels/workbook.xml.rels"), set(copied))
    tgt.set_text("xl/_rels/workbook.xml.rels", rels)

    # 2) attribute plan
    fallback_cm = (prof["by_shape"].get("plain") or {}).get("cm") or (meta["xldapr_cm"] and str(meta["xldapr_cm"])) or "1"
    fallback_vm = (prof["by_shape"].get("plain") or {}).get("vm") or (meta["richvalue_vm"] and str(meta["richvalue_vm"]))

    def plan(body):
        fn = single_call(body)
        names = {c[1] for c in find_calls(body)}
        if fn:
            d = prof["by_function"].get(fn)
            if d:
                return d.get("t"), d.get("cm") or fallback_cm, d.get("vm"), f"donor:{fn}"
            if fn in NUMERIC_FUNCS:
                return None, fallback_cm, fallback_vm, "fallback:plain"
            return "str", (prof["by_shape"].get("text") or {}).get("cm") or fallback_cm, None, "fallback:text"
        if names & NUMERIC_FUNCS:
            d = prof["by_shape"].get("wrapped") or {}
            return None, d.get("cm") or fallback_cm, None, "wrapped" if d else "fallback:wrapped"
        d = prof["by_shape"].get("text") or {}
        return "str", d.get("cm") or fallback_cm, None, "text" if d else "fallback:text"

    # 3) formulas
    counts = collections.Counter()
    unknown = collections.Counter()
    for sname, part in tgt.sheets():
        xml = tgt.text(part)
        pieces, last = [], 0
        for cm, cattrs, inner, fattrs, ftext in iter_formula_cells(xml):
            if not ftext or not CALL_RE.search(ftext):
                continue
            if fattrs.get("t") == "shared":
                warnings.append(f"{sname}!{cattrs.get('r')}: shared formula skipped - expand it before binding")
                continue
            body = ftext
            if a.strip_iferror:
                nb = strip_iferror(body)
                if nb != body:
                    counts["iferror_stripped"] += 1
                body = nb
            for _, fn, _, _, _ in find_calls(body):
                if fn not in KNOWN_FUNCS:
                    unknown[fn] += 1
            body = CALL_RE.sub(lambda m: f"_xldudf_SAP_{m.group(2).upper()}(", body)
            t, cmv, vmv, how = plan(body)
            counts[how] += 1
            ref = cattrs.get("r")
            for k in ("t", "cm", "vm"):
                cattrs.pop(k, None)
            if t:
                cattrs["t"] = t
            cattrs["cm"] = str(cmv)
            if vmv:
                cattrs["vm"] = str(vmv)
            v = "<v></v>" if t == "str" else "<v>0</v>"
            new_cell = f'<c{build_attrs(cattrs)}><f t="array" ref="{ref}">{xml_escape(body)}</f>{v}</c>'
            pieces.append(xml[last:cm.start()])
            pieces.append(new_cell)
            last = cm.end()
        pieces.append(xml[last:])
        tgt.set_text(part, "".join(pieces))
    tgt.set_text("xl/workbook.xml", _set_full_calc(tgt.text("xl/workbook.xml")))
    tgt.save(a.output)

    print(f"bound -> {a.output}")
    print(f"  parts copied: {len(copied)} | content-type overrides added: {n_ct} | workbook rels added: {n_rel}")
    print("  cells: " + ", ".join(f"{k}={v}" for k, v in sorted(counts.items())))
    if any(k.startswith("fallback") for k in counts):
        warnings.append("some cells used fallback cm/vm/t (donor had no cell of that function/shape). "
                        "Safest: add one cell of each function used to the donor and bind again.")
    if unknown:
        warnings.append("unknown SAP functions (not add-in functions, will stay #NAME?): "
                        + ", ".join(f"{k}×{v}" for k, v in unknown.items()))
    for w in warnings:
        print("  WARNING:", w)
    print("\nverification:")
    return cmd_verify(argparse.Namespace(file=a.output, expect_bound=True, expect_getdata=None,
                                         forbid=a.forbid or [], allow_iferror=not a.strip_iferror, quiet=False))


def cmd_verify(a):
    results = []

    def check(name, ok, detail=""):
        results.append((name, ok, detail))

    try:
        with zipfile.ZipFile(a.file) as zf:
            bad = zf.testzip()
        check("zip integrity", bad is None, f"corrupt member: {bad}" if bad else "")
    except zipfile.BadZipFile as e:
        print(f"FAIL zip integrity: {e}")
        return 1
    pkg = Package(a.file)
    names = pkg.defined_names()
    dotted = bound = getdata_bound = iferror = dbl = bare = empty = unknown = 0
    forbid_hits = collections.Counter()
    max_cm = max_vm = 0
    examples = collections.defaultdict(list)
    for sname, part in pkg.sheets():
        for _, cattrs, _, fattrs, ftext in iter_formula_cells(pkg.text(part)):
            if not ftext:
                continue
            if CALL_RE.search(ftext):
                max_cm = max(max_cm, int(cattrs.get("cm", "0") or 0))
                max_vm = max(max_vm, int(cattrs.get("vm", "0") or 0))
            mask = string_mask(ftext)
            stripped = "".join(ch for ch, m in zip(ftext, mask) if not m)
            if re.search(r"==|\+=|-=|\*=|/=|&=|,=|\(=", stripped) or stripped.startswith("="):
                dbl += 1
                examples["double '='"].append(f"{sname}!{cattrs.get('r')}")
            for rx in a.forbid:
                if re.search(rx, ftext):
                    forbid_hits[rx] += 1
                    examples[f"forbid {rx}"].append(f"{sname}!{cattrs.get('r')}")
            for prefix, fn, args, start, end in find_calls(ftext):
                if prefix == "SAP.":
                    dotted += 1
                else:
                    bound += 1
                    if fn == "GETDATA":
                        getdata_bound += 1
                if fn not in KNOWN_FUNCS:
                    unknown += 1
                    examples["unknown function"].append(f"{sname}!{cattrs.get('r')} {fn}")
                if fn in PAIR_FUNCS and args:
                    for i in range(PAIR_FUNCS[fn], len(args), 2):
                        dim = args[i]
                        mem = args[i + 1] if i + 1 < len(args) else None
                        if (IDENT_RE.match(dim) and not REF_TOKEN_RE.match(dim)
                                and dim.upper() not in ("TRUE", "FALSE") and dim not in names):
                            bare += 1
                            examples["bare dimension token"].append(f"{sname}!{cattrs.get('r')} {dim}")
                        if mem == '""':
                            empty += 1
                            examples['empty member ""'].append(f"{sname}!{cattrs.get('r')} {dim}")
            if re.search(r"IFERROR\(\s*(SAP\.|_xldudf_SAP_)(GETDATA|SETDATA)\(", ftext, re.I):
                iferror += 1
                examples["IFERROR around data call"].append(f"{sname}!{cattrs.get('r')}")

    check("unknown SAP functions", unknown == 0, f"{unknown} call(s)")
    check("bare dimension tokens", bare == 0, f"{bare} token(s)")
    check("double '=' / '+=' artefacts", dbl == 0, f"{dbl} cell(s)")
    check('empty member "" in pairs', empty == 0, f"{empty} pair(s)")
    if not a.allow_iferror:
        check("no IFERROR around GETDATA/SETDATA", iferror == 0, f"{iferror} cell(s)")
    for rx, n in forbid_hits.items():
        check(f"forbidden pattern {rx}", False, f"{n} cell(s)")
    if a.expect_bound:
        check("no dotted SAP. formulas left", dotted == 0, f"{dotted} dotted call(s)")
        check("bound _xldudf_SAP_ formulas present", bound > 0, f"{bound} call(s)")
    if a.expect_getdata is not None:
        check(f"_xldudf_SAP_GETDATA count == {a.expect_getdata}", getdata_bound == a.expect_getdata, f"found {getdata_bound}")
    if bound:
        has_meta = pkg.has("xl/metadata.xml")
        check("xl/metadata.xml present", has_meta)
        check("xl/richData/* present", any(n.startswith("xl/richData/") for n in pkg.order))
        ct = pkg.text("[Content_Types].xml")
        check("metadata.xml registered in [Content_Types].xml", "/xl/metadata.xml" in ct)
        rels = pkg.text("xl/_rels/workbook.xml.rels")
        check("metadata.xml referenced in workbook rels", re.search(r'Target="(/xl/)?metadata\.xml"', rels) is not None)
        for n in pkg.order:
            if n.startswith("xl/richData/") and not n.startswith("xl/richData/_rels/"):
                check(f"{n} registered in [Content_Types].xml", "/" + n in ct)
        if has_meta:
            mi = metadata_info(pkg.text("xl/metadata.xml"))
            check("cm indices within cellMetadata", max_cm <= mi["cell_count"], f"max cm={max_cm}, entries={mi['cell_count']}")
            check("vm indices within valueMetadata", max_vm <= mi["value_count"], f"max vm={max_vm}, entries={mi['value_count']}")
        check("fullCalcOnLoad=1", re.search(r'<calcPr\b[^>]*fullCalcOnLoad="(1|true)"', pkg.text("xl/workbook.xml")) is not None)

    failed = [r for r in results if not r[1]]
    if not getattr(a, "quiet", False):
        print(f"  SAP calls: dotted={dotted}, bound={bound} (GETDATA bound={getdata_bound}), IFERROR-wrapped={iferror}")
        for name, ok, detail in results:
            print(f"  {'PASS' if ok else 'FAIL'}  {name}{('  - ' + detail) if detail and not ok else ''}")
        for k, v in examples.items():
            print(f"    {k}: {', '.join(v[:8])}{' …' if len(v) > 8 else ''}")
        print("  RESULT:", "OK" if not failed else f"{len(failed)} check(s) failed")
        print("  Final test: open in Excel with the add-in signed in → Refresh All → compare the reconciliation value.")
    return 1 if failed else 0


def main(argv=None):
    p = argparse.ArgumentParser(prog="sac_xlsx_tools.py", description=__doc__.split("\n\n")[0],
                                formatter_class=argparse.RawDescriptionHelpFormatter, epilog=__doc__)
    p.add_argument("--version", action="version", version=__version__)
    sub = p.add_subparsers(dest="cmd", required=True)

    sp = sub.add_parser("inspect", help="read the add-in state and count SAP formulas")
    sp.add_argument("file"); sp.add_argument("--json", action="store_true")
    sp.add_argument("--raw", action="store_true", help="with --json: include the full state documents")
    sp.add_argument("--formulas", action="store_true", help="list SAP formula cells")
    sp.add_argument("--limit", type=int, default=200)
    sp.set_defaults(func=cmd_inspect)

    sp = sub.add_parser("profile-donor", help="binding parts and cm/vm/t of a donor workbook")
    sp.add_argument("donor"); sp.set_defaults(func=cmd_profile)

    sp = sub.add_parser("bind", help="bind generated SAP formulas using a donor's metadata")
    sp.add_argument("file"); sp.add_argument("--donor", required=True); sp.add_argument("-o", "--output", required=True)
    sp.add_argument("--strip-iferror", action="store_true", help="remove IFERROR wrappers around GETDATA/SETDATA")
    sp.add_argument("--replace-metadata", action="store_true", help="overwrite an existing xl/metadata.xml")
    sp.add_argument("--forbid", action="append", help="regex that must not appear in any formula (repeatable)")
    sp.set_defaults(func=cmd_bind)

    sp = sub.add_parser("verify", help="pre-ship checks (exit 1 on failure)")
    sp.add_argument("file")
    sp.add_argument("--expect-bound", action="store_true", help="require 0 dotted SAP. calls and binding parts")
    sp.add_argument("--expect-getdata", type=int, help="exact number of bound GETDATA calls expected")
    sp.add_argument("--forbid", action="append", default=[], help="regex that must not appear (repeatable)")
    sp.add_argument("--allow-iferror", action="store_true", help="don't fail on IFERROR around data calls")
    sp.set_defaults(func=cmd_verify)

    a = p.parse_args(argv)
    return a.func(a)


if __name__ == "__main__":
    sys.exit(main())
