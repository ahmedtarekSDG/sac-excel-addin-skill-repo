"""Tests for scripts/build_formula.py  -  run: python -m unittest discover -s tests"""
import io
import os
import sys
import unittest
from contextlib import redirect_stdout, redirect_stderr

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "sac-excel-addin-formulas", "scripts"))
import build_formula as bf  # noqa: E402


def run(*argv):
    out, err = io.StringIO(), io.StringIO()
    with redirect_stdout(out), redirect_stderr(err):
        rc = bf.main(list(argv))
    return rc, out.getvalue().strip(), err.getvalue().strip()


class Quoting(unittest.TestCase):
    def test_ids_are_text_even_if_they_look_like_cells(self):
        rc, out, _ = run("GETDATA", "--table", "Table1", "--pairs", "Account=Gross_Margin", "Product=PD19",
                         "CostCenter=CC100", "Date=202501")
        self.assertEqual(rc, 0)
        self.assertEqual(out, '=SAP.GETDATA("Table1","Account","Gross_Margin","Product","PD19",'
                              '"CostCenter","CC100","Date","202501")')

    def test_explicit_refs_stay_bare(self):
        rc, out, _ = run("GETDATA", "--table", "Ctl!$B$3", "--pairs", "Account=$A5", "Date=C$3",
                         "Entity='My Sheet'!$B$2", "Version=ref:B4")
        self.assertEqual(out, "=SAP.GETDATA(Ctl!$B$3,\"Account\",$A5,\"Date\",C$3,\"Entity\",'My Sheet'!$B$2,\"Version\",B4)")

    def test_embedded_quotes_doubled(self):
        rc, out, _ = run("GETDATA", "--table", "DS_1", "--pairs", 'Account=A"B')
        self.assertIn('"A""B"', out)

    def test_semicolon_separator(self):
        rc, out, _ = run("GETDATA", "--sep", ";", "--table", "DS_1", "--pairs", "Account=R")
        self.assertEqual(out, '=SAP.GETDATA("DS_1";"Account";"R")')

    def test_empty_member_rejected(self):
        rc, _, err = run("GETDATA", "--table", "DS_1", "--pairs", "Account=")
        self.assertEqual(rc, 2)
        self.assertIn("unassigned", err)


class Signatures(unittest.TestCase):
    def test_setdata_value_forms(self):
        self.assertIn('=SAP.SETDATA("DS_1",D5,', run("SETDATA", "--table", "DS_1", "--value", "D5", "--pairs", "A=B")[1])
        self.assertIn('=SAP.SETDATA("DS_1",650,', run("SETDATA", "--table", "DS_1", "--value", "650", "--pairs", "A=B")[1])
        self.assertIn('=SAP.SETDATA("DS_1",C8*C9,', run("SETDATA", "--table", "DS_1", "--value", "raw:C8*C9", "--pairs", "A=B")[1])

    def test_getdatacomment_display_second(self):
        rc, out, _ = run("GETDATACOMMENT", "--table", "Table1", "--display", "3", "--pairs", "Account=Gross_Margin")
        self.assertEqual(out, '=SAP.GETDATACOMMENT("Table1",3,"Account","Gross_Margin")')

    def test_overwrite_multi_tables_one_string(self):
        rc, out, _ = run("OVERWRITEDIMENSIONFILTER", "--tables", "Table1", "Table2", "--dimension", "Region",
                         "--members", "$B$6", "--selection-type", "4", "--member-display", "0")
        self.assertEqual(out, '=SAP.OVERWRITEDIMENSIONFILTER("Table1, Table2","Region",$B$6,4,0)')

    def test_overwrite_fills_selection_default(self):
        rc, out, _ = run("OVERWRITEDIMENSIONFILTER", "--tables", "Table1", "--dimension", "Date",
                         "--members", "A9#", "--member-display", "0")
        self.assertEqual(out, '=SAP.OVERWRITEDIMENSIONFILTER("Table1","Date",A9#,0,0)')

    def test_overwrite_selection_range_checked(self):
        rc, _, err = run("OVERWRITEDIMENSIONFILTER", "--tables", "T", "--dimension", "D", "--members", "x",
                         "--selection-type", "6")
        self.assertEqual(rc, 2)

    def test_timeoffset_signature(self):
        rc, out, _ = run("TIMEOFFSET", "--table", "Table2", "--ref", "2022", "--offsets=-1..2")
        self.assertEqual(out, '=SAP.TIMEOFFSET("Table2","2022","-1,0,1,2")')
        rc, out, _ = run("TIMEOFFSET", "--table", "DS_1", "--ref", "$B$5", "--offsets=-11..0", "--orientation", "0")
        self.assertEqual(out, '=SAP.TIMEOFFSET("DS_1",$B$5,"-11,-10,-9,-8,-7,-6,-5,-4,-3,-2,-1,0",0,0)')

    def test_block_and_asymmetric(self):
        self.assertEqual(run("BLOCK", "--pairs", "Version=public.Actual", "Date=G4:G8")[1],
                         '=SAP.BLOCK("Version","public.Actual","Date",G4:G8)')
        self.assertEqual(run("ASYMMETRICFILTER", "--tables", "Table1", "--blocks", "F6:G9", "A10#")[1],
                         '=SAP.ASYMMETRICFILTER("Table1",F6:G9,A10#)')
        self.assertEqual(run("ASYMMETRICFILTER", "--tables", "Table1", "--blocks", "notaref")[0], 2)

    def test_metadata_functions(self):
        self.assertEqual(run("GETDIMENSIONS", "--table", "Table2", "--display", "1", "--orientation", "0", "--sort", "1")[1],
                         '=SAP.GETDIMENSIONS("Table2",1,0,1)')
        self.assertEqual(run("GETDIMENSIONS", "--table", "T", "--sort", "2")[1], '=SAP.GETDIMENSIONS("T",2,0,2)')
        self.assertEqual(run("GETTABLESTATUS", "--tables", "Table1", "Table2", "--display", "4")[1],
                         '=SAP.GETTABLESTATUS("Table1, Table2",4)')
        self.assertEqual(run("GETVARIABLES", "--table", "Table1", "--variable", "City", "--variable-display", "1",
                             "--value-display", "1", "--layout", "3", "--orientation", "0")[1],
                         '=SAP.GETVARIABLES("Table1","City",1,1,3,0)')
        self.assertEqual(run("GETVARIABLES", "--table", "T", "--variable", "V", "--orientation", "0")[0], 2)
        self.assertEqual(run("MEMBERPROPERTY", "--table", "Table1", "--dimension", "Customer", "--members", "$E10",
                             "--properties", "Description, Country (Short_Text)", "--orientation", "0")[1],
                         '=SAP.MEMBERPROPERTY("Table1","Customer",$E10,"Description, Country (Short_Text)",0)')
        self.assertEqual(run("GETDIMENSIONFILTER", "--table", "Table2", "--dimension", "Product",
                             "--member-display", "3", "--selection-display", "1", "--orientation", "0")[1],
                         '=SAP.GETDIMENSIONFILTER("Table2","Product",3,1,0)')

    def test_trigger_functions(self):
        self.assertEqual(run("GETPLANNINGTRIGGERNAME", "--cell", "B2")[1], "=SAP.GETPLANNINGTRIGGERNAME(B2)")
        self.assertEqual(run("GETPLANNINGTRIGGERPARAMETERVALUE", "--trigger", "$B$3", "--parameter", "TargetVersion",
                             "--display", "1", "--orientation", "0")[1],
                         '=SAP.GETPLANNINGTRIGGERPARAMETERVALUE($B$3,"TargetVersion",1,0)')
        self.assertEqual(run("GETPLANNINGTRIGGERPARAMETERS", "--trigger", "T", "--orientation", "0")[0], 2)


class Grid(unittest.TestCase):
    def test_grid_getdata_guarded(self):
        rc, out, _ = run("grid", "--table", "Ctl!$B$3", "--rows", "A5:A6", "--cols", "C3:D3", "--row-dim", "Account",
                         "--col-dim", "Date", "--fixed", "Version=public.Actual", "--guard")
        lines = out.splitlines()
        self.assertEqual(len(lines), 4)
        self.assertEqual(lines[0], 'C5\t=IF($A5="","",SAP.GETDATA(Ctl!$B$3,"Account",$A5,"Date",C$3,"Version","public.Actual"))')
        self.assertTrue(lines[3].startswith("D6\t"))

    def test_grid_setdata_needs_template(self):
        self.assertEqual(run("grid", "--write", "--table", "DS_1", "--rows", "A5:A6", "--cols", "C3:D3",
                             "--row-dim", "A", "--col-dim", "D")[0], 2)
        rc, out, _ = run("grid", "--write", "--value-template", "Input!{col}{row}", "--table", "DS_1", "--rows", "A8:A8",
                         "--cols", "C7:C7", "--row-dim", "Account", "--col-dim", "Date", "--format", "matrix")
        self.assertEqual(out, '=SAP.SETDATA("DS_1",Input!C8,"Account",$A8,"Date",C$7)')


if __name__ == "__main__":
    unittest.main()
