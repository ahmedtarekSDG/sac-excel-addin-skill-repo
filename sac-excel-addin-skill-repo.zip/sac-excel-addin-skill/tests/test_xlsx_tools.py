"""Tests for scripts/sac_xlsx_tools.py using synthetic workbooks.
Needs openpyxl only to create the 'generated' input workbooks (pip install openpyxl).
Run: python -m unittest discover -s tests
"""
import io
import json
import os
import re
import sys
import tempfile
import unittest
import zipfile
from contextlib import redirect_stdout, redirect_stderr

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "sac-excel-addin-formulas", "scripts"))
import sac_xlsx_tools as t  # noqa: E402

try:
    import openpyxl
except ImportError:  # pragma: no cover
    openpyxl = None

METADATA = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<metadata xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:xda="http://schemas.microsoft.com/office/spreadsheetml/2017/dynamicarray" xmlns:xlrd="http://schemas.microsoft.com/office/spreadsheetml/2017/richdata"><metadataTypes count="2"><metadataType name="XLDAPR" minSupportedVersion="120000" copy="1" pasteAll="1" pasteValues="1" merge="1" splitFirst="1" rowColShift="1" clearFormats="1" clearComments="1" assign="1" coerce="1" cellMeta="1"/><metadataType name="XLRICHVALUE" minSupportedVersion="120000" copy="1" pasteAll="1" pasteValues="1" merge="1" splitFirst="1" rowColShift="1" clearFormats="1" clearComments="1" assign="1" coerce="1"/></metadataTypes><futureMetadata name="XLDAPR" count="1"><bk><extLst><ext uri="{bdbb8cdc-fa1e-496e-a857-3c3f30c029c3}"><xda:dynamicArrayProperties fDynamic="1" fCollapsed="0"/></ext></extLst></bk></futureMetadata><futureMetadata name="XLRICHVALUE" count="2"><bk><extLst><ext uri="{3e2802c4-a4d2-4d8b-9148-e3be6c30e623}"><xlrd:rvb i="0"/></ext></extLst></bk><bk><extLst><ext uri="{3e2802c4-a4d2-4d8b-9148-e3be6c30e623}"><xlrd:rvb i="1"/></ext></extLst></bk></futureMetadata><cellMetadata count="1"><bk><rc t="1" v="0"/></bk></cellMetadata><valueMetadata count="2"><bk><rc t="2" v="0"/></bk><bk><rc t="2" v="1"/></bk></valueMetadata></metadata>"""

RICH = {
    "xl/richData/rdrichvalue.xml": '<rvData xmlns="http://schemas.microsoft.com/office/spreadsheetml/2017/richdata" count="2"><rv s="0"><v>0</v></rv><rv s="0"><v>0</v></rv></rvData>',
    "xl/richData/rdrichvaluestructure.xml": '<rvStructures xmlns="http://schemas.microsoft.com/office/spreadsheetml/2017/richdata" count="1"><s t="_error"><k n="errorType" t="i"/></s></rvStructures>',
    "xl/richData/richStyles.xml": '<richStyleSheet xmlns="http://schemas.microsoft.com/office/spreadsheetml/2017/richdata2"/>',
    "xl/richData/rdRichValueTypes.xml": '<rvTypesInfo xmlns="http://schemas.microsoft.com/office/spreadsheetml/2017/richdata2"/>',
}
CT = {
    "/xl/metadata.xml": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheetMetadata+xml",
    "/xl/richData/rdrichvalue.xml": "application/vnd.ms-excel.rdrichvalue+xml",
    "/xl/richData/rdrichvaluestructure.xml": "application/vnd.ms-excel.rdrichvaluestructure+xml",
    "/xl/richData/richStyles.xml": "application/vnd.ms-excel.richstyles+xml",
    "/xl/richData/rdRichValueTypes.xml": "application/vnd.ms-excel.rdrichvaluetypes+xml",
}
RELS = {
    "metadata.xml": "http://schemas.openxmlformats.org/officeDocument/2006/relationships/sheetMetadata",
    "richData/rdrichvalue.xml": "http://schemas.microsoft.com/office/2017/06/relationships/rdRichValue",
    "richData/rdrichvaluestructure.xml": "http://schemas.microsoft.com/office/2017/06/relationships/rdRichValueStructure",
    "richData/richStyles.xml": "http://schemas.microsoft.com/office/2017/06/relationships/richStyles",
    "richData/rdRichValueTypes.xml": "http://schemas.microsoft.com/office/2017/06/relationships/rdRichValueTypes",
}
STATE = {"document": {
    "dataSources": {"byId": {"ds1": {"modelName": "SALES_MODEL", "connection": "LIVE", "schema": "SPACE_A"}}},
    "queries": {"byId": {"Query1": {
        "dataSourceId": "ds1", "rows": ["Account"], "columns": ["Date"],
        "availables": [
            {"id": "Account", "description": "Account", "isMeasureDimension": False, "isDateOrTimeDimension": False},
            {"id": "_CALMONTH", "description": "Calendar Month", "isMeasureDimension": False, "isDateOrTimeDimension": True},
            {"id": "CustomDimension1", "description": "Measures", "isMeasureDimension": True, "isDateOrTimeDimension": False}],
        "dimensionFilters": {"Account": ["[Account].[H1].&[REVENUE]"]}}}}}}


def run(*argv):
    out, err = io.StringIO(), io.StringIO()
    with redirect_stdout(out), redirect_stderr(err):
        rc = t.main(list(argv))
    return rc, out.getvalue(), err.getvalue()


def patch_zip(src, dst, edit):
    with zipfile.ZipFile(src) as zf:
        parts = {i.filename: zf.read(i.filename) for i in zf.infolist()}
        order = [i.filename for i in zf.infolist()]
    edit(parts, order)
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as zf:
        for n in order:
            zf.writestr(n, parts[n])


@unittest.skipIf(openpyxl is None, "openpyxl not installed")
class Workflow(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.dir = tempfile.mkdtemp()
        d = cls.dir
        # --- donor: Excel-bound look-alike -------------------------------------------------
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Sheet1"
        ws["A1"] = '=SAP.GETDATA("DS_1")'
        ws["A2"] = "=SAP.GETTABLENAME(B1)"
        ws["A3"] = '=IF(1,SAP.GETDATA("DS_1"))'
        raw = os.path.join(d, "donor_raw.xlsx")
        wb.save(raw)

        def make_donor(parts, order):
            parts["xl/metadata.xml"] = METADATA.encode()
            order.append("xl/metadata.xml")
            for k, v in RICH.items():
                parts[k] = v.encode()
                order.append(k)
            ct = parts["[Content_Types].xml"].decode()
            ct = ct.replace("</Types>", "".join(f'<Override PartName="{p}" ContentType="{c}"/>' for p, c in CT.items()) + "</Types>")
            parts["[Content_Types].xml"] = ct.encode()
            rels = parts["xl/_rels/workbook.xml.rels"].decode()
            rels = rels.replace("</Relationships>", "".join(
                f'<Relationship Id="rIdM{i}" Type="{ty}" Target="{tg}"/>' for i, (tg, ty) in enumerate(RELS.items())) + "</Relationships>")
            parts["xl/_rels/workbook.xml.rels"] = rels.encode()
            sh = parts["xl/worksheets/sheet1.xml"].decode()
            sh = re.sub(r'<c r="A1"[^>]*>.*?</c>', '<c r="A1" cm="1" vm="2"><f t="array" ref="A1">_xldudf_SAP_GETDATA("DS_1")</f><v>0</v></c>', sh, flags=re.S)
            sh = re.sub(r'<c r="A2"[^>]*>.*?</c>', '<c r="A2" t="str" cm="1"><f t="array" ref="A2">_xldudf_SAP_GETTABLENAME(B1)</f><v>Table1</v></c>', sh, flags=re.S)
            sh = re.sub(r'<c r="A3"[^>]*>.*?</c>', '<c r="A3" cm="1"><f t="array" ref="A3">IF(1,_xldudf_SAP_GETDATA("DS_1"))</f><v>0</v></c>', sh, flags=re.S)
            parts["xl/worksheets/sheet1.xml"] = sh.encode()
            parts["customXml/item1.xml"] = ("<?xml version=\"1.0\"?><x><![CDATA[" + json.dumps(STATE) + "]]></x>").encode()
            order.append("customXml/item1.xml")

        cls.donor = os.path.join(d, "donor.xlsx")
        patch_zip(raw, cls.donor, make_donor)

        # --- generated workbook (what a script writes) --------------------------------------
        wb = openpyxl.Workbook()
        ctl = wb.active
        ctl.title = "Ctl"
        ctl["B3"] = "DS_1"
        ctl["B4"] = '=IFERROR(SAP.GETTABLENAME(data!A1),"DS_1")'
        rep = wb.create_sheet("Report")
        rep["C5"] = '=SAP.GETDATA(Ctl!$B$3,"Account",$A5,"Date",C$3)'
        rep["C6"] = '=IF($A6="",0,SAP.GETDATA(Ctl!$B$3,"Account",$A6,"Date",C$3))'
        rep["C7"] = '=IFERROR(SAP.GETDATA(Ctl!$B$3,"Account",$A7,"Date",C$3),"")'
        rep["C8"] = '=SAP.GETDATA(Ctl!$B$3,"Account","R&D<1>","Date",C$3)'
        rep["D5"] = '=SAP.OVERWRITEDIMENSIONFILTER("Table1, Table2","Region",Ctl!$B$6,4,0)'
        rep["E5"] = "=C5-C6"
        wb.create_sheet("data")
        cls.generated = os.path.join(d, "generated.xlsx")
        wb.save(cls.generated)

        # --- a broken workbook for verify ---------------------------------------------------
        wb = openpyxl.Workbook()
        ws = wb.active
        ws["A1"] = '=SAP.GETDATA("DS_1",PROFIT_CENTER,$A5)'
        ws["A2"] = '==IF(1,2,3)+=IF(1,2,3)'
        ws["A3"] = '=SAP.GETMEMBERS("DS_1","Account")'
        ws["A4"] = '=IFERROR(SAP.GETDATA("DS_1","Account","R"),"")'
        ws["A5"] = '=SAP.GETDATA("DS_1","Account","")'
        cls.bad = os.path.join(d, "bad.xlsx")
        wb.save(cls.bad)

    def test_profile_donor(self):
        prof = t.donor_profile(t.Package(self.donor))
        self.assertEqual(prof["by_function"]["GETDATA"], {"t": None, "cm": "1", "vm": "2"})
        self.assertEqual(prof["by_function"]["GETTABLENAME"]["t"], "str")
        self.assertEqual(prof["by_shape"]["wrapped"]["cm"], "1")
        self.assertEqual(prof["metadata"]["xldapr_cm"], 1)
        self.assertEqual(prof["metadata"]["richvalue_vm"], 1)

    def test_inspect_reads_state(self):
        rc, out, _ = run("inspect", self.donor, "--json")
        data = json.loads(out)
        dims = [d["id"] for d in data["state"][0]["queries"][0]["dimensions"]]
        self.assertEqual(dims, ["Account", "_CALMONTH", "CustomDimension1"])
        self.assertEqual(data["state"][0]["memberUniqueNames"][0]["member"], "REVENUE")
        rc, out, _ = run("inspect", self.donor)
        self.assertIn("_CALMONTH", out)
        self.assertIn("[measure]", out)

    def test_bind_and_verify(self):
        out_path = os.path.join(self.dir, "bound.xlsx")
        rc, out, err = run("bind", self.generated, "--donor", self.donor, "-o", out_path, "--strip-iferror")
        self.assertEqual(rc, 0, out + err)
        self.assertIn("RESULT: OK", out)
        with zipfile.ZipFile(out_path) as zf:
            self.assertIsNone(zf.testzip())
            names = zf.namelist()
            self.assertIn("xl/metadata.xml", names)
            self.assertIn("xl/richData/rdrichvalue.xml", names)
            rep = zf.read("xl/worksheets/sheet2.xml").decode()
            ctl = zf.read("xl/worksheets/sheet1.xml").decode()
            ct = zf.read("[Content_Types].xml").decode()
            rels = zf.read("xl/_rels/workbook.xml.rels").decode()
            wbx = zf.read("xl/workbook.xml").decode()
        self.assertRegex(rep, r'<c r="C5"[^>]*cm="1" vm="2"><f t="array" ref="C5">_xldudf_SAP_GETDATA\(Ctl!\$B\$3,"Account",\$A5,"Date",C\$3\)</f><v>0</v></c>')
        self.assertRegex(rep, r'<c r="C6"[^>]*cm="1"><f t="array" ref="C6">IF\(\$A6="",0,_xldudf_SAP_GETDATA')
        self.assertNotIn("vm", re.search(r'<c r="C6"[^>]*>', rep).group(0))
        self.assertRegex(rep, r'<c r="C7"[^>]*vm="2"><f t="array" ref="C7">_xldudf_SAP_GETDATA\(')  # IFERROR stripped
        self.assertIn("R&amp;D&lt;1&gt;", rep)
        self.assertRegex(rep, r'<c r="D5"[^>]*t="str" cm="1"><f t="array" ref="D5">_xldudf_SAP_OVERWRITEDIMENSIONFILTER')
        self.assertRegex(rep, r'<c r="E5"[^>]*><f>C5-C6</f>')  # native formula untouched
        self.assertRegex(ctl, r'<c r="B4"[^>]*t="str" cm="1"><f t="array" ref="B4">IFERROR\(_xldudf_SAP_GETTABLENAME')
        self.assertIn('PartName="/xl/metadata.xml"', ct)
        self.assertIn('Target="metadata.xml"', rels)
        self.assertRegex(rels, r'Id="rId900\d"')
        self.assertIn('fullCalcOnLoad="1"', wbx)
        self.assertNotRegex(rep, r"(?<!_)SAP\.GETDATA")
        # file still opens
        openpyxl.load_workbook(out_path)

    def test_bind_refuses_unbound_donor(self):
        rc, _, err = run("bind", self.generated, "--donor", self.generated, "-o", os.path.join(self.dir, "x.xlsx"))
        self.assertEqual(rc, 2)
        self.assertIn("donor has no", err)

    def test_verify_catches_problems(self):
        rc, out, _ = run("verify", self.bad)
        self.assertEqual(rc, 1)
        for needle in ("FAIL  unknown SAP functions", "FAIL  bare dimension tokens", "FAIL  double '='",
                       'FAIL  empty member ""', "FAIL  no IFERROR around GETDATA/SETDATA"):
            self.assertIn(needle, out)
        self.assertIn("PROFIT_CENTER", out)
        self.assertIn("GETMEMBERS", out)

    def test_verify_expect_bound_on_generated_fails(self):
        rc, out, _ = run("verify", self.generated, "--expect-bound", "--allow-iferror")
        self.assertEqual(rc, 1)
        self.assertIn("FAIL  no dotted SAP. formulas left", out)

    def test_strip_iferror_balanced(self):
        self.assertEqual(t.strip_iferror('IFERROR(SAP.GETDATA("a",IF(1,"x,y",2)),"-")+1'),
                         'SAP.GETDATA("a",IF(1,"x,y",2))+1')
        self.assertEqual(t.strip_iferror('IFERROR(A1/B1,"-")'), 'IFERROR(A1/B1,"-")')

    def test_split_args_and_calls(self):
        calls = t.find_calls('IF(A1="SAP.GETDATA(",0,SAP.GETDATA("T","D",SUM(1,2)))')
        self.assertEqual(len(calls), 1)
        self.assertEqual(calls[0][2], ['"T"', '"D"', 'SUM(1,2)'])


if __name__ == "__main__":
    unittest.main()
